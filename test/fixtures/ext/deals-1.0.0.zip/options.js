const $ = (id) => document.getElementById(id), S = MFX.store, K = 'deals.opts';
$('stmt').textContent = MFDeals.AFFILIATE_STATEMENT;
(async () => {
  const o = Object.assign({ alerts: true, recheckHours: 12, syncUrl: '' }, await S.get(K, {}));
  $('alerts').checked = o.alerts; $('hours').value = String(o.recheckHours); $('sync').value = o.syncUrl;
  const save = async () => {
    const u = $('sync').value.trim();
    if (u && !MFDeals.validSyncUrl(u)) { $('serr').textContent = 'Use a secure https address'; return; }
    $('serr').textContent = '';
    await S.set(K, { alerts: $('alerts').checked, recheckHours: +$('hours').value, syncUrl: u });
  };
  ['alerts', 'hours', 'sync'].forEach((id) => $(id).addEventListener('change', save));
  $('perm').onclick = async () => { const ok = await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] }); $('pmsg').textContent = ok ? 'Allowed' : 'Not allowed. Alerts then only update when you visit a page.'; };
  $('recheck').onclick = async () => { const r = await chrome.runtime.sendMessage({ type: 'deals.recheck' }); $('pmsg').textContent = r.error || ('Checked ' + r.checked + ' pages'); };
  $('export').onclick = async () => {
    const data = { history: await S.get('deals.hist', {}), watch: await S.get('deals.watch', {}), coupons: await S.get('deals.coupons', {}) };
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })); a.download = 'mayfair-deals.json'; a.click();
  };
  $('wipe').onclick = async () => { await S.set('deals.hist', {}); await S.set('deals.watch', {}); $('dmsg').textContent = 'Price history deleted'; };
})();
