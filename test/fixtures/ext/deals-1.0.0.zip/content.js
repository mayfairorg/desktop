/* Reads schema.org Product data from the page and tells the background.  Reads only; never changes the page or its links. */
(function () {
  if (window.top !== window) return;
  const D = globalThis.MFDeals;
  function read() {
    const nodes = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => nodes.push(...D.parseJsonLd(s.textContent)));
    let p = D.findProducts(nodes)[0];
    if (!p) {
      const m = {};
      document.querySelectorAll('meta[property],meta[name],meta[itemprop]').forEach((e) => { const k = e.getAttribute('property') || e.getAttribute('name') || e.getAttribute('itemprop'); if (k && e.content) m[k] = e.content; });
      m.title = document.title;
      p = D.metaProduct(m);
    }
    return p || null;
  }
  let last = '';
  function send() {
    const p = read(); const sig = p ? p.name + p.price : '';
    if (sig === last) return; last = sig;
    chrome.runtime.sendMessage({ type: 'deals.product', url: location.href, product: p }).catch(() => {});
  }
  send();
  /* single-page shops fill the markup late: look again a few times, then stop */
  let n = 0; const iv = setInterval(() => { send(); if (++n >= 4) clearInterval(iv); }, 2000);
  chrome.runtime.onMessage.addListener((m, _s, reply) => { if (m && m.type === 'deals.read') { reply({ product: read() }); } });
})();
