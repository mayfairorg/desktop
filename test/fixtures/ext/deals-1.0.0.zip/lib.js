/* Deals: pure logic (no browser APIs).  UMD so node:test can load it. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFDeals = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_POINTS = 200, MIN_GAP_MS = 12 * 3600e3, COUPON_STALE_MS = 180 * 86400e3;

  /* "1,299.00", "1.299,00", "£12", "12,5", 12 -> number | null */
  function normalizePrice(v) {
    if (typeof v === 'number') return isFinite(v) && v >= 0 ? v : null;
    let s = String(v == null ? '' : v).replace(/[^\d.,]/g, '');
    if (!s) return null;
    const lc = s.lastIndexOf(','), ld = s.lastIndexOf('.');
    if (lc > -1 && ld > -1) s = lc > ld ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else if (lc > -1) s = /,\d{1,2}$/.test(s) && (s.match(/,/g) || []).length === 1 ? s.replace(',', '.') : s.replace(/,/g, '');
    else if ((s.match(/\./g) || []).length > 1) s = s.replace(/\./g, '');
    const n = parseFloat(s);
    return isFinite(n) && n >= 0 ? n : null;
  }

  function parseJsonLd(text) {
    try { const j = JSON.parse(String(text).trim()); return Array.isArray(j) ? j : [j]; } catch { return []; }
  }
  const types = (n) => [].concat(n && n['@type'] || []).map(String);
  function flatten(nodes, out) {
    out = out || [];
    for (const n of nodes) {
      if (!n || typeof n !== 'object') continue;
      out.push(n);
      if (Array.isArray(n['@graph'])) flatten(n['@graph'], out);
      if (n.mainEntity && typeof n.mainEntity === 'object') flatten([].concat(n.mainEntity), out);
    }
    return out;
  }
  function offerPrice(o) {
    const list = [].concat(o || []).filter((x) => x && typeof x === 'object');
    let best = null;
    for (const x of list) {
      const inner = x.offers ? offerPrice(x.offers) : null;
      const spec = x.priceSpecification ? [].concat(x.priceSpecification)[0] : null;
      const p = normalizePrice(x.price != null ? x.price : x.lowPrice != null ? x.lowPrice : spec && spec.price);
      const cand = p != null ? { price: p, currency: x.priceCurrency || (spec && spec.priceCurrency) || '', availability: String(x.availability || '').split('/').pop() } : inner;
      if (cand && (!best || cand.price < best.price)) best = cand;
    }
    return best;
  }
  /* schema.org Product nodes -> [{name, price, currency, sku, image, availability}] */
  function findProducts(jsonLdNodes) {
    const res = [];
    for (const n of flatten(jsonLdNodes)) {
      if (!types(n).includes('Product') && !types(n).includes('ProductGroup')) continue;
      const o = offerPrice(n.offers) || (n.hasVariant ? offerPrice([].concat(n.hasVariant).map((v) => v && v.offers).filter(Boolean)) : null);
      if (!o || !n.name) continue;
      const img = [].concat(n.image || [])[0];
      res.push({ name: String(n.name).trim().slice(0, 200), price: o.price, currency: o.currency, availability: o.availability, sku: String(n.sku || n.gtin13 || n.gtin || n.mpn || ''), image: typeof img === 'string' ? img : (img && img.url) || '' });
    }
    return res;
  }
  /* meta tags (og:price:amount, product:price:amount, itemprop) as a plain {name:content} map */
  function metaProduct(m) {
    const price = normalizePrice(m['product:price:amount'] || m['og:price:amount'] || m['twitter:data1'] && /\d/.test(m['twitter:data1']) && m['twitter:data1'] || m['price']);
    if (price == null) return null;
    const name = m['og:title'] || m['twitter:title'] || m['title'];
    if (!name) return null;
    return { name: String(name).trim().slice(0, 200), price, currency: m['product:price:currency'] || m['og:price:currency'] || '', availability: '', sku: '', image: m['og:image'] || '' };
  }
  /* for background re-checks: no DOM in a service worker, so pick the blocks out of raw html */
  function extractFromHtml(html) {
    html = String(html || '');
    const nodes = [];
    const re = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi; let m;
    while ((m = re.exec(html))) nodes.push(...parseJsonLd(m[1]));
    const p = findProducts(nodes);
    if (p.length) return p[0];
    const meta = {}; const mr = /<meta\s+[^>]*?(?:property|name|itemprop)=["']([^"']+)["'][^>]*?content=["']([^"']*)["'][^>]*>/gi;
    while ((m = mr.exec(html))) meta[m[1]] = m[2];
    const t = /<title[^>]*>([^<]*)<\/title>/i.exec(html); if (t && !meta['og:title']) meta.title = t[1];
    return metaProduct(meta);
  }

  /* One key per product page on one site: query and hash do not count. */
  function productKey(url) {
    try { const u = new URL(url); return u.hostname.replace(/^www\./, '').toLowerCase() + (u.pathname.replace(/\/+$/, '') || '/'); } catch { return ''; }
  }

  function addPoint(history, price, ts) {
    const h = (history || []).slice(), last = h[h.length - 1];
    if (!last || last.p !== price || ts - last.t >= MIN_GAP_MS) h.push({ t: ts, p: price });
    return h.length > MAX_POINTS ? h.slice(h.length - MAX_POINTS) : h;
  }
  function stats(history) {
    if (!history || !history.length) return null;
    const ps = history.map((x) => x.p), cur = ps[ps.length - 1];
    const min = Math.min(...ps), max = Math.max(...ps), avg = ps.reduce((a, b) => a + b, 0) / ps.length;
    const prev = (() => { for (let i = ps.length - 2; i >= 0; i--) if (ps[i] !== cur) return ps[i]; return null; })();
    return { cur, min, max, avg, prev, n: ps.length, atLow: ps.length > 1 && cur <= min, vsAvgPct: avg ? Math.round((cur - avg) / avg * 100) : 0, since: history[0].t };
  }
  /* watch = {target?: number, dropPct?: number}.  An alert is raised when the price is at/below the target, or fell by dropPct from the last different price. */
  function dropAlert(history, watch) {
    const s = stats(history); if (!s || !watch) return null;
    if (watch.target != null && s.cur <= watch.target) return { kind: 'target', price: s.cur, was: s.prev };
    if (watch.dropPct && s.prev != null && s.cur < s.prev && (s.prev - s.cur) / s.prev * 100 >= watch.dropPct) return { kind: 'drop', price: s.cur, was: s.prev, pct: Math.round((s.prev - s.cur) / s.prev * 100) };
    return null;
  }
  function sparkPath(history, w, h, pad) {
    pad = pad == null ? 2 : pad;
    if (!history || history.length < 2) return '';
    const t0 = history[0].t, t1 = history[history.length - 1].t || t0 + 1;
    const ps = history.map((x) => x.p), lo = Math.min(...ps), hi = Math.max(...ps), span = hi - lo || 1, ts = t1 - t0 || 1;
    return history.map((x, i) => (i ? 'L' : 'M') + (pad + (x.t - t0) / ts * (w - 2 * pad)).toFixed(1) + ' ' + (h - pad - (x.p - lo) / span * (h - 2 * pad)).toFixed(1)).join('');
  }

  /* ----- coupons: user-submitted, stored locally ----- */
  const CODE_RE = /^[A-Z0-9][A-Z0-9_-]{2,31}$/;
  function cleanCode(c) { const s = String(c || '').trim().toUpperCase().replace(/\s+/g, ''); return CODE_RE.test(s) ? s : null; }
  function addCoupon(list, code, note, ts) {
    const c = cleanCode(code); if (!c) return { list, error: 'A code is 3 to 32 letters, numbers, - or _' };
    list = (list || []).slice();
    if (list.some((x) => x.code === c)) return { list, error: 'Already saved' };
    list.push({ code: c, note: String(note || '').trim().slice(0, 120), up: 0, down: 0, t: ts });
    return { list };
  }
  function vote(list, code, dir, ts) {
    return (list || []).map((x) => x.code === code ? Object.assign({}, x, dir > 0 ? { up: x.up + 1 } : { down: x.down + 1 }, { t: ts }) : x);
  }
  /* smoothed success rate, older codes count for less */
  function couponScore(c, now) {
    const base = (c.up + 1) / (c.up + c.down + 2);
    return base * ((now - c.t) > COUPON_STALE_MS ? 0.5 : 1);
  }
  function rankCoupons(list, now) {
    return (list || []).slice().sort((a, b) => couponScore(b, now) - couponScore(a, now) || b.t - a.t);
  }
  /* the only data that would ever leave the device, and only when the user set an endpoint */
  function syncPayload(domain, list) { return { v: 1, domain, coupons: (list || []).map((c) => ({ code: c.code, note: c.note, up: c.up, down: c.down, t: c.t })) }; }
  function mergeCoupons(local, remote, now) {
    const by = new Map((local || []).map((c) => [c.code, Object.assign({}, c)]));
    for (const r of remote || []) {
      const code = cleanCode(r && r.code); if (!code) continue;
      const l = by.get(code);
      if (!l) by.set(code, { code, note: String(r.note || '').slice(0, 120), up: Math.max(0, r.up | 0), down: Math.max(0, r.down | 0), t: r.t | 0 || now });
      else { l.up = Math.max(l.up, r.up | 0); l.down = Math.max(l.down, r.down | 0); l.t = Math.max(l.t, r.t | 0); }
    }
    return [...by.values()];
  }
  function validSyncUrl(u) { try { const x = new URL(u); return x.protocol === 'https:' && !x.username && !x.password; } catch { return false; } }

  const AFFILIATE_STATEMENT = 'Mayfair Deals never changes your links, never adds an affiliate tag and never redirects a page. It earns nothing from what you buy.';

  return { normalizePrice, parseJsonLd, findProducts, metaProduct, extractFromHtml, productKey, addPoint, stats, dropAlert, sparkPath, cleanCode, addCoupon, vote, couponScore, rankCoupons, syncPayload, mergeCoupons, validSyncUrl, AFFILIATE_STATEMENT, MAX_POINTS };
});
