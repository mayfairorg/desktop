const D = MFDeals, $ = (id) => document.getElementById(id), send = (m) => chrome.runtime.sendMessage(m);
let tab, st;
function money(n) { return MFX.fmtMoney(n, st.entry && st.entry.currency); }
function drawPrice() {
  const el = $('price'), e = st.entry, s = st.stats;
  if (!e || !s) { el.innerHTML = '<div class="empty"><b>No price found on this page</b>Open a product page and the price is saved here each time you visit.</div>'; return; }
  const path = D.sparkPath(e.points, 300, 56);
  const note = s.atLow ? '<span class="ok">Lowest price seen</span>' : s.prev != null && s.cur < s.prev ? '<span class="ok">Down from ' + money(s.prev) + '</span>' : s.prev != null && s.cur > s.prev ? '<span class="err">Up from ' + money(s.prev) + '</span>' : '<span class="mute">Same as before</span>';
  const w = st.watch;
  el.innerHTML = '<div class="price">' + MFX.esc(money(s.cur)) + '</div><div>' + note + '</div>' +
    (path ? '<svg class="spark" viewBox="0 0 300 56" preserveAspectRatio="none" role="img" aria-label="Price history"><path d="' + path + '"/></svg>' : '') +
    '<div class="note">Low ' + money(s.min) + ' · High ' + money(s.max) + ' · ' + s.n + ' visits since ' + new Date(s.since).toLocaleDateString() + '</div>' +
    '<div class="bar" style="margin-top:8px"><button class="btn sm" id="w">' + (w ? 'Stop watching' : 'Tell me when it drops') + '</button></div>';
  $('w').onclick = async () => { await send({ type: 'deals.watch', key: st.key, watch: w ? null : { target: null, dropPct: 5 } }); load(); };
}
function drawCoupons() {
  const el = $('coupons');
  if (!st.coupons.length) { el.innerHTML = '<div class="empty"><b>No codes for ' + MFX.esc(st.host) + ' yet</b>Saved a code that worked? Add it for next time.</div>'; return; }
  el.innerHTML = st.coupons.map((c) => '<div class="row"><div class="grow"><span class="code">' + MFX.esc(c.code) + '</span>' + (c.note ? '<small style="display:block">' + MFX.esc(c.note) + '</small>' : '') + '<small>' + c.up + ' worked · ' + c.down + ' did not</small></div>' +
    '<button class="btn sm" data-a="copy" data-c="' + MFX.esc(c.code) + '" aria-label="Copy ' + MFX.esc(c.code) + '">Copy</button><button class="btn sm" data-a="up" data-c="' + MFX.esc(c.code) + '" aria-label="It worked">Worked</button><button class="btn sm" data-a="down" data-c="' + MFX.esc(c.code) + '" aria-label="It did not work">No</button></div>').join('');
}
$('coupons').onclick = async (e) => {
  const b = e.target.closest('button'); if (!b) return; const code = b.dataset.c;
  if (b.dataset.a === 'copy') { await navigator.clipboard.writeText(code).catch(() => {}); b.textContent = 'Copied'; return; }
  const r = await send({ type: 'deals.vote', host: st.host, code, dir: b.dataset.a === 'up' ? 1 : -1 }); st.coupons = r.coupons; drawCoupons();
};
$('add').onsubmit = async (e) => {
  e.preventDefault();
  const r = await send({ type: 'deals.addCoupon', host: st.host, code: $('code').value, note: '' });
  $('cerr').textContent = r.error || ''; if (!r.error) { $('code').value = ''; st.coupons = r.coupons; drawCoupons(); }
};
$('sync').onclick = async () => { const r = await send({ type: 'deals.sync', host: st.host }); $('cerr').className = 'note ' + (r.error ? 'err' : 'ok'); $('cerr').textContent = r.error || 'Synced'; if (!r.error) load(); };
$('opt').onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };
async function load() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !MFX.isHttp(tab.url)) { $('price').innerHTML = '<div class="empty"><b>Nothing to read here</b>Open a shop page.</div>'; $('coupons').innerHTML = ''; $('add').hidden = true; return; }
  st = await send({ type: 'deals.state', url: tab.url });
  $('host').textContent = st.host; $('sync').hidden = !st.syncOn; $('stmt').textContent = st.statement; drawPrice(); drawCoupons();
}
load();
