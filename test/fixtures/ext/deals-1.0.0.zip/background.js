importScripts('mf.js', 'lib.js');
const D = MFDeals, S = MFX.store;
const K = { hist: 'deals.hist', watch: 'deals.watch', coupons: 'deals.coupons', opts: 'deals.opts' };
const OPTS = { alerts: true, recheckHours: 12, syncUrl: '' };

async function opts() { return Object.assign({}, OPTS, await S.get(K.opts, {})); }

async function record(url, product, ts) {
  const key = D.productKey(url); if (!key || !product) return null;
  const all = await S.get(K.hist, {});
  const e = all[key] || { name: product.name, currency: product.currency, url: url.split('#')[0], points: [] };
  e.name = product.name; e.currency = product.currency || e.currency; e.image = product.image || e.image; e.url = url.split('#')[0];
  e.points = D.addPoint(e.points, product.price, ts);
  all[key] = e;
  /* keep the history of at most 300 products, oldest touched first out */
  const keys = Object.keys(all);
  if (keys.length > 300) keys.sort((a, b) => (all[a].points.at(-1).t) - (all[b].points.at(-1).t)).slice(0, keys.length - 300).forEach((k) => delete all[k]);
  await S.set(K.hist, all);
  await maybeAlert(key, e);
  return { key, entry: e };
}

async function maybeAlert(key, e) {
  const o = await opts(); if (!o.alerts) return;
  const watch = (await S.get(K.watch, {}))[key]; if (!watch) return;
  const a = D.dropAlert(e.points, watch); if (!a) return;
  if (watch.lastAlertPrice === a.price) return;
  const w = await S.get(K.watch, {}); w[key].lastAlertPrice = a.price; await S.set(K.watch, w);
  chrome.notifications.create('deal:' + key, { type: 'basic', iconUrl: 'icons/icon128.png', title: 'Price dropped', message: e.name.slice(0, 80) + ' is now ' + MFX.fmtMoney(a.price, e.currency) + (a.was ? ' (was ' + MFX.fmtMoney(a.was, e.currency) + ')' : '') });
}

async function badge(tabId, key) {
  const all = await S.get(K.hist, {}), e = all[key], s = e && D.stats(e.points);
  const down = s && s.prev != null && s.cur < s.prev;
  await chrome.action.setBadgeText({ tabId, text: down ? '↓' : s ? '' : '' });
  if (down) await chrome.action.setBadgeBackgroundColor({ tabId, color: '#ffa800' });
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === 'deals.product' && sender.tab) {
      const r = await record(m.url, m.product, Date.now());
      if (r) await badge(sender.tab.id, r.key);
      reply({ ok: true });
    } else if (m.type === 'deals.state') {
      const key = D.productKey(m.url), all = await S.get(K.hist, {}), host = MFX.hostOf(m.url);
      const cl = (await S.get(K.coupons, {}))[host] || [];
      reply({ key, host, entry: all[key] || null, stats: all[key] ? D.stats(all[key].points) : null, watch: (await S.get(K.watch, {}))[key] || null, coupons: D.rankCoupons(cl, Date.now()), syncOn: D.validSyncUrl((await opts()).syncUrl), statement: D.AFFILIATE_STATEMENT });
    } else if (m.type === 'deals.watch') {
      const w = await S.get(K.watch, {});
      if (m.watch) w[m.key] = { target: m.watch.target == null ? null : +m.watch.target, dropPct: m.watch.dropPct ? +m.watch.dropPct : 0 }; else delete w[m.key];
      await S.set(K.watch, w); reply({ ok: true });
    } else if (m.type === 'deals.addCoupon') {
      const all = await S.get(K.coupons, {}), r = D.addCoupon(all[m.host], m.code, m.note, Date.now());
      if (!r.error) { all[m.host] = r.list; await S.set(K.coupons, all); }
      reply({ error: r.error || null, coupons: D.rankCoupons(all[m.host], Date.now()) });
    } else if (m.type === 'deals.vote') {
      const all = await S.get(K.coupons, {}); all[m.host] = D.vote(all[m.host], m.code, m.dir, Date.now()); await S.set(K.coupons, all);
      reply({ coupons: D.rankCoupons(all[m.host], Date.now()) });
    } else if (m.type === 'deals.removeCoupon') {
      const all = await S.get(K.coupons, {}); all[m.host] = (all[m.host] || []).filter((c) => c.code !== m.code); await S.set(K.coupons, all);
      reply({ coupons: D.rankCoupons(all[m.host], Date.now()) });
    } else if (m.type === 'deals.sync') { reply(await sync(m.host)); }
    else if (m.type === 'deals.recheck') { reply(await recheck()); }
    else reply(null);
  })().catch((e) => reply({ error: String(e && e.message || e) }));
  return true;
});

/* Optional sync with an endpoint the user typed in the options.  Off by default, https only, sends coupon codes and nothing else. */
async function sync(host) {
  const o = await opts(); if (!D.validSyncUrl(o.syncUrl)) return { error: 'No sync address set' };
  const all = await S.get(K.coupons, {});
  const body = JSON.stringify(D.syncPayload(host, all[host]));
  const r = await fetch(o.syncUrl, { method: 'POST', headers: { 'content-type': 'application/json' }, body, credentials: 'omit' });
  if (!r.ok) return { error: 'The sync address answered ' + r.status };
  const j = await r.json().catch(() => null);
  if (j && Array.isArray(j.coupons)) { all[host] = D.mergeCoupons(all[host], j.coupons, Date.now()); await S.set(K.coupons, all); }
  return { ok: true };
}

/* Re-read the watched pages on a timer.  Needs the optional "all sites" permission (asked from the options page). */
async function recheck() {
  if (!(await chrome.permissions.contains({ origins: ['<all_urls>'] }))) return { error: 'Needs permission to read watched pages' };
  const w = await S.get(K.watch, {}), all = await S.get(K.hist, {}); let n = 0;
  for (const key of Object.keys(w)) {
    const e = all[key]; if (!e || !e.url) continue;
    try {
      const r = await fetch(e.url, { credentials: 'omit', cache: 'no-store' }); if (!r.ok) continue;
      const p = D.extractFromHtml((await r.text()).slice(0, 2e6)); if (p) { await record(e.url, p, Date.now()); n++; }
    } catch { /* offline: try again next time */ }
  }
  return { ok: true, checked: n };
}

async function schedule() {
  const o = await opts();
  chrome.alarms.create('deals.recheck', { periodInMinutes: Math.max(60, o.recheckHours * 60) });
}
chrome.runtime.onInstalled.addListener(schedule);
chrome.runtime.onStartup.addListener(schedule);
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'deals.recheck') recheck(); });
chrome.storage.onChanged.addListener((c) => { if (c[K.opts]) schedule(); });
chrome.notifications.onClicked.addListener(async (id) => {
  if (!id.startsWith('deal:')) return; const all = await S.get(K.hist, {}), e = all[id.slice(5)]; if (e) chrome.tabs.create({ url: e.url });
});
