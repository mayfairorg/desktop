/* Fills a login form when the person asks.  Never on its own, never in frames, only on secure pages. */
(function () {
  if (window.top !== window) return;
  const P = globalThis.MFPw;
  const visible = (e) => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 4 && r.height > 4 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const desc = (e) => ({ type: (e.getAttribute('type') || 'text').toLowerCase(), name: e.name || '', id: e.id || '', autocomplete: e.autocomplete || '', placeholder: e.placeholder || '', ariaLabel: e.getAttribute('aria-label') || '', visible: visible(e), disabled: e.disabled, readOnly: e.readOnly });
  const inputs = () => [...document.querySelectorAll('input')].filter((e) => !['hidden', 'checkbox', 'radio', 'submit', 'button', 'file', 'image'].includes((e.getAttribute('type') || 'text').toLowerCase()));
  function setValue(el, v) {
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set; set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function scan() {
    const els = inputs(), ds = els.map(desc), c = P.classify(ds);
    return { els, c, userOnly: c.password === -1 ? P.usernameOnly(ds) : -1 };
  }
  let found = false;
  function report() {
    const s = scan(), has = s.c.password !== -1 || s.userOnly !== -1;
    if (has !== found) { found = has; chrome.runtime.sendMessage({ type: 'pw.found', has, signup: s.c.newPassword }).catch(() => {}); }
  }
  report(); new MutationObserver(() => { clearTimeout(report.t); report.t = setTimeout(report, 400); }).observe(document.documentElement, { childList: true, subtree: true });

  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type === 'pw.probe') { const s = scan(); reply({ origin: location.origin, ok: P.fillableOrigin(location.origin), has: s.c.password !== -1 || s.userOnly !== -1, signup: s.c.newPassword, username: s.c.username !== -1 ? s.els[s.c.username].value : '' }); return; }
    if (m.type === 'pw.fill') {
      if (m.origin !== location.origin || !P.fillableOrigin(location.origin)) { reply({ ok: false, reason: 'origin' }); return; }
      const creds = P.cleanCreds(m.credentials), s = scan(); let cred;
      if (s.c.newPassword) { reply({ ok: false, reason: 'signup' }); return; }
      if (!creds.length) { reply({ ok: false, reason: 'none' }); return; }
      cred = P.pick(creds, s.c.username !== -1 ? s.els[s.c.username].value : '');
      if (s.c.password !== -1) {
        if (s.c.username !== -1 && cred.username) setValue(s.els[s.c.username], cred.username);
        setValue(s.els[s.c.password], cred.password); s.els[s.c.password].focus();
      } else if (s.userOnly !== -1 && cred.username) setValue(s.els[s.userOnly], cred.username);
      reply({ ok: true }); return;
    }
  });
})();
