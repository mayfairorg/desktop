/* Passwords autofill hook: pure logic.  The extension never stores a password; Mayfair Passwords answers each request. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFPw = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  /* An input is {type,name,id,autocomplete,placeholder,ariaLabel,visible,disabled,readOnly}. */
  const txt = (i) => [i.name, i.id, i.autocomplete, i.placeholder, i.ariaLabel].join(' ').toLowerCase();
  function isPassword(i) { return i.type === 'password'; }
  function userScore(i) {
    if (!i.visible || i.disabled || i.readOnly) return -1;
    if (!['text', 'email', 'tel', ''].includes(i.type || '')) return -1;
    const t = txt(i); let s = 0;
    if (/\busername\b/.test(i.autocomplete || '')) s += 6;
    if (/(user|login|email|e-mail|account|identifier|signin|uid)/.test(t)) s += 4;
    if (i.type === 'email') s += 2;
    if (/(search|query|coupon|promo|captcha|zip|postal|phone|address|first|last|company)/.test(t)) s -= 6;
    return s;
  }
  /* Returns indexes into `inputs` for the fields to fill. */
  function classify(inputs) {
    const pwIdx = inputs.map((x, k) => [x, k]).filter(([x]) => isPassword(x) && x.visible && !x.disabled && !x.readOnly).map(([, k]) => k);
    if (!pwIdx.length) return { password: -1, username: -1, newPassword: false };
    const explicitCur = pwIdx.find((k) => /current-password/.test(inputs[k].autocomplete || ''));
    const plainCur = pwIdx.find((k) => !/new-password/.test(inputs[k].autocomplete || ''));
    const cur = explicitCur !== undefined ? explicitCur : plainCur;
    /* sign-up forms (several password boxes with none marked "current", or only new-password boxes) are not auto-filled */
    const newPassword = explicitCur === undefined && (pwIdx.length >= 2 || cur === undefined);
    const password = cur === undefined ? pwIdx[0] : cur;
    let username = -1, best = 0;
    for (let k = password - 1; k >= 0; k--) { const s = userScore(inputs[k]); if (s > best) { best = s; username = k; } if (s >= 6) break; }
    return { password, username, newPassword: !!newPassword };
  }
  /* A login page that only shows the username (first step of a two step sign-in) */
  function usernameOnly(inputs) {
    if (inputs.some(isPassword)) return -1;
    let best = 0, at = -1; inputs.forEach((i, k) => { const s = userScore(i); if (s > best) { best = s; at = k; } });
    return best >= 6 ? at : -1;
  }
  function fillableOrigin(origin) {
    try { const u = new URL(origin); return u.protocol === 'https:' || (u.protocol === 'http:' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')); } catch { return false; }
  }
  function cleanCreds(list) {
    return (Array.isArray(list) ? list : []).filter((c) => c && typeof c === 'object').slice(0, 20).map((c) => ({ username: String(c.username || '').slice(0, 256), password: String(c.password || '').slice(0, 1024), label: c.label ? String(c.label).slice(0, 80) : '' })).filter((c) => c.password);
  }
  function pick(creds, usernameHint) {
    if (!creds.length) return null;
    const h = String(usernameHint || '').toLowerCase();
    return (h && creds.find((c) => c.username.toLowerCase() === h)) || creds[0];
  }
  return { classify, usernameOnly, userScore, fillableOrigin, cleanCreds, pick };
});
