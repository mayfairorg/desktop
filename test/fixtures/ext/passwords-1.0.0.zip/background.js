importScripts('mf.js', 'lib.js');
const X = MFX, P = MFPw, pending = new Map();   /* request id -> {tabId, origin}; in memory only, dropped after 30 s */
const MAYFAIR = X.MAYFAIR_ORIGINS.map((o) => o + '/*');

async function request(tabId) {
  const probe = await chrome.tabs.sendMessage(tabId, { type: 'pw.probe' }).catch(() => null);
  if (!probe) return { error: 'This page cannot be filled' };
  if (!probe.ok) return { error: 'Passwords only fill on secure pages' };
  if (!probe.has) return { error: 'No sign-in form on this page' };
  if (probe.signup) return { error: 'This looks like a sign-up form. Use Mayfair Passwords to make a new password.' };
  const tabs = await chrome.tabs.query({ url: MAYFAIR });
  if (!tabs.length) return { error: 'Open Mayfair Passwords first', needMayfair: true };
  const env = X.envelope(X.MSG.PW_REQ, { origin: probe.origin, host: X.hostOf(probe.origin) });
  pending.set(env.id, { tabId, origin: probe.origin }); setTimeout(() => pending.delete(env.id), 30000);
  chrome.tabs.sendMessage(tabs[0].id, { type: 'bridge.out', envelope: env }).catch(() => {});
  return { ok: true, id: env.id };
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === 'pw.request') reply(await request(m.tabId));
    else if (m.type === 'pw.found' && sender.tab) { chrome.action.setBadgeText({ tabId: sender.tab.id, text: m.has && !m.signup ? '•' : '' }); chrome.action.setBadgeBackgroundColor({ color: '#ffa800' }); reply(null); }
    else if (m.type === 'bridge.in' && sender.tab && X.isMayfairOrigin(new URL(sender.tab.url).origin) && X.validEnvelope(m.envelope) && m.envelope.type === X.MSG.PW_RES) {
      const p = m.envelope.payload || {}, w = pending.get(p.id); reply(null);
      if (!w) return; pending.delete(p.id);
      chrome.tabs.sendMessage(w.tabId, { type: 'pw.fill', origin: w.origin, credentials: P.cleanCreds(p.credentials) }).catch(() => {});
    } else reply(null);
  })().catch(() => reply(null));
  return true;
});
chrome.commands.onCommand.addListener(async (c) => { if (c !== 'fill') return; const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); if (t) request(t.id); });
chrome.runtime.onInstalled.addListener(() => chrome.contextMenus.create({ id: 'fill', title: 'Fill from Mayfair Passwords', contexts: ['editable'] }));
chrome.contextMenus.onClicked.addListener((i, t) => { if (i.menuItemId === 'fill' && t) request(t.id); });
