/* Runs only on the Mayfair web app.  Relays between the extension and the page with postMessage.
   Same-window, same-origin messages only; the page decides what to do with a clip.  (Stub contract v1: see README.) */
(function () {
  if (window.top !== window) return;
  const X = globalThis.MFX;
  const post = (env) => window.postMessage(env, location.origin);
  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'bridge.out' && X.validEnvelope(m.envelope)) post(m.envelope); });
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin || !X.validEnvelope(e.data)) return;
    if (e.data.type === X.MSG.CLIP_ACK || e.data.type === X.MSG.PW_RES) chrome.runtime.sendMessage({ type: 'bridge.in', envelope: e.data }).catch(() => {});
  });
  chrome.runtime.sendMessage({ type: 'bridge.hello' }).catch(() => {});
  post(X.envelope(X.MSG.HELLO, { ext: 'clipper', v: 1 }));
})();
