const $ = (id) => document.getElementById(id);
(async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('host').textContent = t ? MFX.hostOf(t.url) : '';
  $('fill').onclick = async () => {
    const r = await chrome.runtime.sendMessage({ type: 'pw.request', tabId: t.id });
    $('msg').className = 'note ' + (r.ok ? 'ok' : 'err');
    $('msg').textContent = r.ok ? 'Asked Mayfair Passwords. Pick a login there if it asks.' : r.error;
    if (r.needMayfair) { const b = document.createElement('button'); b.className = 'btn sm'; b.textContent = 'Open Mayfair'; b.onclick = () => chrome.tabs.create({ url: 'https://cloud.mayfairmail.com/' }); $('msg').after(b); }
  };
})();
