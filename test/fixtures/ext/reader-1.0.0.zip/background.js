async function toggle(tab) {
  if (!tab || !/^https?:/.test(tab.url || '')) return;
  const r = await chrome.tabs.sendMessage(tab.id, { type: 'reader.toggle' }).catch(() => null);
  if (r && r.ok === false) { chrome.action.setBadgeText({ tabId: tab.id, text: '?' }); setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: '' }), 2500); }
}
chrome.action.onClicked.addListener(toggle);
chrome.commands.onCommand.addListener(async (c) => { if (c === 'toggle-reader') { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); toggle(t); } });
chrome.runtime.onInstalled.addListener(() => chrome.contextMenus.create({ id: 'reader', title: 'Open in reader view', contexts: ['page'] }));
chrome.contextMenus.onClicked.addListener((i, t) => { if (i.menuItemId === 'reader') toggle(t); });
