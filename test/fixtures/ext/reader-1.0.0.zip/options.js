const $ = (id) => document.getElementById(id), R = MFReader;
chrome.storage.local.get('reader.prefs').then((r) => { const p = R.cleanPrefs(r['reader.prefs']); ['theme', 'font', 'size', 'width'].forEach((k) => $(k).value = p[k]); });
['theme', 'font', 'size', 'width'].forEach((k) => $(k).addEventListener('change', async () => {
  const p = R.cleanPrefs({ theme: $('theme').value, font: $('font').value, size: $('size').value, width: $('width').value });
  await chrome.storage.local.set({ 'reader.prefs': p }); ['size', 'width'].forEach((q) => $(q).value = p[q]); $('msg').textContent = 'Saved';
}));
