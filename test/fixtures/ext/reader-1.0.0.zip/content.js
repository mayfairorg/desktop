/* Reader view in a closed shadow root over the page.  Builds nodes with textContent only. */
(function () {
  if (window.top !== window || window.__mfReader) return; window.__mfReader = 1;
  const R = globalThis.MFReader; let host = null;
  const own = (n) => [...n.childNodes].filter((c) => c.nodeType === 3).map((c) => c.nodeValue).join('');
  function tree(n, d) {
    const t = n.tagName.toLowerCase(); if (d > 40) return { tag: t, children: [] };
    const o = { tag: t, cls: typeof n.className === 'string' ? n.className : '', id: n.id || '', text: own(n), children: [] };
    if (t === 'img') { o.src = n.currentSrc || n.src || n.getAttribute('data-src') || ''; o.alt = n.alt || ''; }
    for (const c of n.children) { if (o.children.length < 800) o.children.push(tree(c, d + 1)); }
    return o;
  }
  const meta = (p) => { const e = document.querySelector('meta[property="' + p + '"],meta[name="' + p + '"]'); return e ? e.content : ''; };
  function read() {
    const t = tree(document.body, 0), a = R.pickArticle(t); if (!a) return null;
    const blocks = R.toBlocks(a, location.href), h1 = document.querySelector('h1');
    return { title: R.pickTitle(h1 && h1.textContent, meta('og:title'), document.title), site: meta('og:site_name') || location.hostname.replace(/^www\./, ''), blocks, words: R.words(blocks) };
  }
  async function open() {
    const art = read();
    if (!art || !art.blocks.length) return { ok: false, reason: 'No article found on this page' };
    const prefs = R.cleanPrefs((await chrome.storage.local.get('reader.prefs'))['reader.prefs']);
    host = document.createElement('div'); host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647';
    const sh = host.attachShadow({ mode: 'closed' }); const root = document.createElement('div'); sh.append(root);
    const st = document.createElement('style');
    st.textContent = '.r{position:absolute;inset:0;overflow:auto;font-family:var(--f);font-size:var(--s);line-height:1.7;background:var(--bg);color:var(--fg)}.bar{position:sticky;top:0;display:flex;gap:8px;align-items:center;justify-content:flex-end;padding:8px 16px;background:var(--bg);border-bottom:1px solid var(--line);font:500 14px system-ui,sans-serif}button{min-height:44px;min-width:44px;padding:0 14px;border-radius:8px;border:1px solid var(--line);background:transparent;color:var(--fg);font:500 14px system-ui,sans-serif;cursor:pointer}button:focus-visible{outline:2px solid #ffa800;outline-offset:2px}article{max-width:var(--w);margin:0 auto;padding:32px 16px 96px}h1{font-size:1.9em;line-height:1.2;margin:0 0 8px}.meta{color:var(--mute);font:14px system-ui,sans-serif;margin-bottom:32px}h2,h3,h4{line-height:1.3;margin:1.6em 0 .5em}p{margin:0 0 1em}blockquote{margin:1em 0;padding-left:16px;border-left:3px solid var(--line);color:var(--mute)}pre{overflow:auto;padding:12px;border:1px solid var(--line);border-radius:8px;font-size:.8em;line-height:1.5}img{max-width:100%;height:auto;display:block;margin:1em auto;border-radius:8px}li{margin:0 0 .4em 1.2em;display:list-item}';
    root.append(st);
    const apply = () => { const th = R.THEMES[prefs.theme]; const s = root.style; s.setProperty('--bg', th.bg); s.setProperty('--fg', th.fg); s.setProperty('--mute', th.mute); s.setProperty('--line', th.line); s.setProperty('--s', prefs.size + 'px'); s.setProperty('--w', prefs.width + 'px'); s.setProperty('--f', prefs.font === 'serif' ? 'Georgia,"Times New Roman",serif' : 'Inter,system-ui,sans-serif'); chrome.storage.local.set({ 'reader.prefs': prefs }); };
    const el = (tag, txt, cls) => { const e = document.createElement(tag); if (txt != null) e.textContent = txt; if (cls) e.className = cls; return e; };
    const wrap = el('div', null, 'r'); const bar = el('div', null, 'bar');
    const btn = (label, fn, aria) => { const b = el('button', label); b.setAttribute('aria-label', aria || label); b.onclick = fn; bar.append(b); return b; };
    btn('A-', () => { prefs.size = Math.max(14, prefs.size - 2); apply(); }, 'Smaller text'); btn('A+', () => { prefs.size = Math.min(32, prefs.size + 2); apply(); }, 'Larger text');
    btn('Font', () => { prefs.font = prefs.font === 'serif' ? 'sans' : 'serif'; apply(); }, 'Change font');
    btn('Theme', () => { const k = Object.keys(R.THEMES); prefs.theme = k[(k.indexOf(prefs.theme) + 1) % k.length]; apply(); }, 'Change theme');
    btn('Close', close, 'Close reader');
    const art_ = el('article'); art_.append(el('h1', art.title)); art_.append(el('div', art.site + ' · ' + R.minutes(art.words) + ' min read', 'meta'));
    for (const b of art.blocks) {
      if (b.t === 'img') { const i = document.createElement('img'); i.src = b.src; i.alt = b.alt; i.loading = 'lazy'; i.referrerPolicy = 'no-referrer'; art_.append(i); }
      else art_.append(el({ p: 'p', quote: 'blockquote', pre: 'pre', li: 'li' }[b.t] || b.t, b.text));
    }
    wrap.append(bar, art_); root.append(wrap); apply(); document.documentElement.append(host);
    document.documentElement.style.overflow = 'hidden'; wrap.tabIndex = -1; wrap.focus();
    wrap.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    return { ok: true };
  }
  function close() { if (host) { host.remove(); host = null; document.documentElement.style.overflow = ''; } }
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m.type === 'reader.toggle') { if (host) { close(); reply({ ok: true, open: false }); } else open().then((r) => reply(Object.assign({ open: !!r.ok }, r))); return true; }
    if (m.type === 'reader.check') { const a = read(); reply({ readable: !!a && R.readable(a.blocks) }); }
  });
})();
