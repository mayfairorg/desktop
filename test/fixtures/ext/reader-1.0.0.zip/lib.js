/* Reader mode: article picking over a plain node tree {tag, cls, id, text, href, src, alt, children}.  `text` is the node's own text. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFReader = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const UNLIKELY = /(comment|sidebar|footer|foot|nav|menu|banner|promo|advert|\bads?\b|sponsor|share|social|related|recommend|cookie|popup|modal|subscribe|newsletter|breadcrumb|pagination|widget)/i;
  const LIKELY = /(article|body|content|entry|main|post|story|text|blog)/i;
  const SKIP_TAGS = new Set(['script', 'style', 'noscript', 'nav', 'footer', 'aside', 'form', 'iframe', 'button', 'select', 'svg', 'canvas', 'header']);
  const kids = (n) => n.children || [];

  function textOf(n) { return (n.text || '') + kids(n).map(textOf).join(' '); }
  function linkTextLen(n, inLink) {
    const a = inLink || n.tag === 'a';
    return (a ? (n.text || '').length : 0) + kids(n).reduce((s, c) => s + linkTextLen(c, a), 0);
  }
  const unlikely = (n) => { const s = (n.cls || '') + ' ' + (n.id || ''); return SKIP_TAGS.has(n.tag) || (UNLIKELY.test(s) && !LIKELY.test(s)); };

  /* score each container by the paragraphs under it: length, commas, penalise link-heavy blocks */
  function pickArticle(rootNode) {
    const scores = new Map();
    const bump = (n, v) => scores.set(n, (scores.get(n) || 0) + v);
    (function walk(n, parent, grand) {
      if (unlikely(n)) return;
      if (['p', 'pre', 'td', 'blockquote'].includes(n.tag)) {
        const t = textOf(n).trim();
        if (t.length >= 25) {
          const v = 1 + Math.min(3, Math.floor(t.length / 100)) + (t.match(/[,;]/g) || []).length * 0.5;
          if (parent) bump(parent, v); if (grand) bump(grand, v / 2);
        }
      }
      for (const c of kids(n)) walk(c, n, parent);
    })(rootNode, null, null);
    let best = null, bs = 0;
    for (const [n, s] of scores) {
      const tl = textOf(n).length || 1, ld = linkTextLen(n) / tl;
      const adj = s * (1 - Math.min(0.9, ld)) + (LIKELY.test((n.cls || '') + ' ' + (n.id || '')) ? 3 : 0) + (n.tag === 'article' ? 4 : 0);
      if (adj > bs) { bs = adj; best = n; }
    }
    return bs >= 4 ? best : null;
  }

  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  function safeHref(h, base) { try { const u = new URL(h, base); return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; } }
  /* the article as flat blocks of plain text: nothing from the page's markup is ever inserted as html */
  function toBlocks(node, base) {
    const out = [];
    (function walk(n) {
      if (SKIP_TAGS.has(n.tag) || (UNLIKELY.test((n.cls || '') + ' ' + (n.id || '')) && !LIKELY.test((n.cls || '') + ' ' + (n.id || '')))) return;
      const t = n.tag;
      if (/^h[1-6]$/.test(t)) { const s = clean(textOf(n)); if (s) out.push({ t: 'h' + Math.max(2, +t[1]), text: s }); return; }
      if (t === 'p') { const s = clean(textOf(n)); if (s.length >= 2 && !(linkTextLen(n) / (s.length || 1) > 0.8 && s.length < 60)) out.push({ t: 'p', text: s }); return; }
      if (t === 'blockquote') { const s = clean(textOf(n)); if (s) out.push({ t: 'quote', text: s }); return; }
      if (t === 'pre') { const s = textOf(n).replace(/\s+$/, ''); if (s) out.push({ t: 'pre', text: s }); return; }
      if (t === 'li') { const s = clean(textOf(n)); if (s) out.push({ t: 'li', text: s }); return; }
      if (t === 'img' && n.src) { const src = safeHref(n.src, base); if (src && !/(pixel|spacer|tracking|1x1)/i.test(src)) out.push({ t: 'img', src, alt: clean(n.alt) }); return; }
      if (n.text && clean(n.text).length > 40 && !kids(n).length) { out.push({ t: 'p', text: clean(n.text) }); return; }
      kids(n).forEach(walk);
    })(node);
    return out;
  }
  const words = (blocks) => blocks.reduce((s, b) => s + (b.text ? clean(b.text).split(' ').filter(Boolean).length : 0), 0);
  const minutes = (w) => Math.max(1, Math.round(w / 230));
  function pickTitle(h1, og, doc) {
    const c = [h1, og, doc].map(clean).filter(Boolean); let t = c[0] || 'Untitled';
    const d = clean(doc);
    if (!h1 && !og && d) t = d.split(/\s[|–—-]\s/)[0] || d;
    return t.slice(0, 200);
  }
  /* is it worth offering reader mode at all */
  function readable(blocks) { return words(blocks) >= 150 && blocks.filter((b) => b.t === 'p').length >= 3; }

  const THEMES = { light: { bg: '#ffffff', fg: '#1b1b19', mute: '#5b5b57', line: '#d8d8d4', link: '#7a4b00' }, sepia: { bg: '#f4ecd8', fg: '#3a2f1c', mute: '#6b5a3c', line: '#d9cdae', link: '#7a4b00' }, dark: { bg: '#171716', fg: '#f1f1ee', mute: '#a3a39d', line: '#34342f', link: '#ffa800' } };
  const DEFAULTS = { theme: 'dark', size: 19, font: 'serif', width: 680 };
  function cleanPrefs(p) {
    p = p || {};
    return { theme: THEMES[p.theme] ? p.theme : DEFAULTS.theme, size: Math.min(32, Math.max(14, +p.size || DEFAULTS.size)), font: p.font === 'sans' ? 'sans' : 'serif', width: Math.min(900, Math.max(480, +p.width || DEFAULTS.width)) };
  }
  return { pickArticle, toBlocks, textOf, linkTextLen, words, minutes, pickTitle, readable, cleanPrefs, THEMES, DEFAULTS, safeHref };
});
