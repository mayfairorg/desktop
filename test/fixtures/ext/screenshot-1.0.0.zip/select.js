/* Injected on request: draw a box with the mouse and report its corners.  Esc cancels. */
(function () {
  if (window.__mfShotSel) return; window.__mfShotSel = 1;
  const host = document.createElement('div'); host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;cursor:crosshair;background:rgba(0,0,0,.25)';
  const box = document.createElement('div'); box.style.cssText = 'position:fixed;border:2px solid #ffa800;background:rgba(255,168,0,.12);display:none;pointer-events:none';
  const tip = document.createElement('div'); tip.textContent = 'Drag to choose an area. Esc to cancel.'; tip.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);padding:8px 14px;border-radius:8px;background:#171716;color:#f1f1ee;font:500 14px system-ui,sans-serif';
  host.append(box, tip); document.documentElement.append(host);
  let a = null;
  const done = (rect) => { host.remove(); window.__mfShotSel = 0; removeEventListener('keydown', key, true); chrome.runtime.sendMessage({ type: 'shot.area', rect, viewW: innerWidth, viewH: innerHeight, dpr: devicePixelRatio }); };
  const key = (e) => { if (e.key === 'Escape') { e.preventDefault(); done(null); } };
  addEventListener('keydown', key, true);
  host.addEventListener('pointerdown', (e) => { a = { x: e.clientX, y: e.clientY }; host.setPointerCapture(e.pointerId); box.style.display = 'block'; });
  host.addEventListener('pointermove', (e) => { if (!a) return; const x = Math.min(a.x, e.clientX), y = Math.min(a.y, e.clientY); Object.assign(box.style, { left: x + 'px', top: y + 'px', width: Math.abs(e.clientX - a.x) + 'px', height: Math.abs(e.clientY - a.y) + 'px' }); });
  host.addEventListener('pointerup', (e) => { if (!a) return; const b = { x: e.clientX, y: e.clientY }; const s = a; a = null; host.style.visibility = 'hidden'; setTimeout(() => done({ a: s, b }), 120); });
})();
