/* Screenshot: pure logic. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFShot = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_PX = 16000;   // a canvas side the browser can hold
  /* scroll positions (css px) that cover a page of `pageH` with a window of `viewH`; the last one is clamped so it ends at the page bottom */
  function planScroll(pageH, viewH, dpr) {
    dpr = dpr || 1; const maxCss = Math.floor(MAX_PX / dpr); const total = Math.min(pageH, maxCss);
    if (viewH <= 0 || total <= viewH) return { offsets: [0], height: Math.min(total, Math.max(viewH, 0) || total), truncated: pageH > maxCss };
    const offsets = []; for (let y = 0; y + viewH < total; y += viewH) offsets.push(y);
    offsets.push(total - viewH);
    return { offsets, height: total, truncated: pageH > maxCss };
  }
  /* a drag from (x1,y1) to (x2,y2) in css px -> a clamped rectangle in device px */
  function cropRect(a, b, viewW, viewH, dpr) {
    const x = Math.max(0, Math.min(a.x, b.x)), y = Math.max(0, Math.min(a.y, b.y));
    const w = Math.min(viewW, Math.max(a.x, b.x)) - x, h = Math.min(viewH, Math.max(a.y, b.y)) - y;
    if (w < 4 || h < 4) return null;
    return { x: Math.round(x * dpr), y: Math.round(y * dpr), w: Math.round(w * dpr), h: Math.round(h * dpr) };
  }
  const pad = (n) => String(n).padStart(2, '0');
  function fileName(title, now, mode) {
    const d = new Date(now), base = String(title || 'page').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 60) || 'page';
    return 'Mayfair ' + base + ' ' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + '.' + pad(d.getMinutes()) + '.' + pad(d.getSeconds()) + (mode === 'full' ? ' full' : '') + '.png';
  }
  /* captureVisibleTab is limited to about 2 calls a second */
  const CAPTURE_GAP_MS = 600;
  return { planScroll, cropRect, fileName, MAX_PX, CAPTURE_GAP_MS };
});
