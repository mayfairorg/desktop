const $ = (id) => document.getElementById(id), M = MFShot;
document.querySelector('.bar').onclick = async (e) => {
  const b = e.target.closest('[data-m]'); if (!b) return; const mode = b.dataset.m;
  document.querySelectorAll('button').forEach((x) => x.disabled = true); $('msg').className = 'note'; $('msg').textContent = mode === 'full' ? 'Capturing the whole page, keep this window open' : 'Capturing';
  const r = await chrome.runtime.sendMessage({ type: 'shot.take', mode });
  document.querySelectorAll('button').forEach((x) => x.disabled = false);
  if (r.error) { $('msg').className = 'note err'; $('msg').textContent = r.error; return; }
  if (mode === 'area') { window.close(); return; }
  const name = M.fileName(r.title, Date.now(), mode);
  $('msg').className = 'note ok'; $('msg').textContent = r.truncated ? 'Captured the first part of a very long page' : 'Captured';
  $('out').innerHTML = '<img class="pv" alt="Preview of the screenshot" src="' + r.dataUrl + '"><div class="bar"><button class="btn primary sm" id="save">Save</button><button class="btn sm" id="copy">Copy</button></div>';
  $('save').onclick = () => chrome.downloads.download({ url: r.dataUrl, filename: name });
  $('copy').onclick = async () => { try { const blob = await (await fetch(r.dataUrl)).blob(); await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); $('copy').textContent = 'Copied'; } catch { $('copy').textContent = 'Could not copy'; } };
};
