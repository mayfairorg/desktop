importScripts('mf.js', 'lib.js');
const M = MFShot, sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cap = (winId) => chrome.tabs.captureVisibleTab(winId, { format: 'png' });
const toBitmap = async (url) => createImageBitmap(await (await fetch(url)).blob());
async function toDataUrl(canvas) { const b = await canvas.convertToBlob({ type: 'image/png' }); const buf = new Uint8Array(await b.arrayBuffer()); let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000)); return 'data:image/png;base64,' + btoa(s); }
const run = (tabId, func, args) => chrome.scripting.executeScript({ target: { tabId }, func, args: args || [] }).then((r) => r[0].result);

async function visible(tab) { return { dataUrl: await cap(tab.windowId) }; }

async function full(tab) {
  const m = await run(tab.id, () => ({ h: Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0), vh: innerHeight, vw: innerWidth, dpr: devicePixelRatio, y: scrollY }));
  const plan = M.planScroll(m.h, m.vh, m.dpr);
  const cv = new OffscreenCanvas(Math.round(m.vw * m.dpr), Math.round(plan.height * m.dpr)), ctx = cv.getContext('2d');
  let last = 0;
  for (const y of plan.offsets) {
    await run(tab.id, (yy) => scrollTo(0, yy), [y]);
    const wait = Math.max(250, M.CAPTURE_GAP_MS - (Date.now() - last)); await sleep(wait);
    const bmp = await toBitmap(await cap(tab.windowId)); last = Date.now();
    ctx.drawImage(bmp, 0, Math.round(y * m.dpr)); bmp.close && bmp.close();
  }
  await run(tab.id, (yy) => scrollTo(0, yy), [m.y]);
  return { dataUrl: await toDataUrl(cv), truncated: plan.truncated };
}

let waitingArea = null;
async function area(tab) {
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['select.js'] });
  waitingArea = { tab };
  return { ok: true };
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === 'shot.take') {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !/^https?:|^file:/.test(tab.url || '')) return reply({ error: 'This page cannot be captured' });
      try { reply(Object.assign({ title: tab.title }, m.mode === 'full' ? await full(tab) : m.mode === 'area' ? await area(tab) : await visible(tab))); } catch (e) { reply({ error: 'Could not capture this page' }); }
    } else if (m.type === 'shot.area' && waitingArea && sender.tab && sender.tab.id === waitingArea.tab.id) {
      const tab = waitingArea.tab; waitingArea = null; reply(null);
      if (!m.rect) return;
      const r = M.cropRect(m.rect.a, m.rect.b, m.viewW, m.viewH, m.dpr); if (!r) return;
      const bmp = await toBitmap(await cap(tab.windowId)), cv = new OffscreenCanvas(r.w, r.h);
      cv.getContext('2d').drawImage(bmp, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h);
      chrome.downloads.download({ url: await toDataUrl(cv), filename: M.fileName(tab.title, Date.now(), 'area'), saveAs: false });
    } else reply(null);
  })();
  return true;
});
