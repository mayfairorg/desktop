/* Shows the translation next to the selection in a small closed shadow-root bubble.  Text only. */
(function () {
  if (window.top !== window) return; let host = null;
  const close = () => { if (host) { host.remove(); host = null; } };
  function show(r) {
    close(); const sel = getSelection(); let x = 16, y = 16;
    if (sel && sel.rangeCount) { const b = sel.getRangeAt(0).getBoundingClientRect(); if (b.width || b.height) { x = Math.min(Math.max(8, b.left), innerWidth - 328); y = Math.min(b.bottom + 8, innerHeight - 140); } }
    host = document.createElement('div'); host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:' + x + 'px;top:' + y + 'px';
    const sh = host.attachShadow({ mode: 'closed' }), box = document.createElement('div');
    const st = document.createElement('style'); st.textContent = '.b{width:320px;max-width:calc(100vw - 16px);box-sizing:border-box;padding:12px 14px;border-radius:12px;background:#171716;color:#f1f1ee;border:1px solid #34342f;box-shadow:0 8px 28px rgba(0,0,0,.4);font:14px/1.45 system-ui,sans-serif}.l{color:#a3a39d;font-size:12px;margin-bottom:6px}.t{white-space:pre-wrap;word-break:break-word;font-size:15px}.n{color:#a3a39d;font-size:12px;margin-top:8px}button{margin-top:8px;min-height:44px;min-width:44px;padding:0 14px;border-radius:8px;border:1px solid #34342f;background:#1f1f1d;color:#f1f1ee;font:500 14px system-ui,sans-serif;cursor:pointer}button:focus-visible{outline:2px solid #ffa800;outline-offset:2px}';
    box.className = 'b'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Translation');
    const mk = (cls, t) => { const d = document.createElement('div'); d.className = cls; d.textContent = t; return d; };
    if (r.error) box.append(mk('t', r.error));
    else { box.append(mk('l', (r.names ? r.names[r.from] + ' to ' + r.names[r.to] : r.from + ' to ' + r.to)), mk('t', r.text), mk('n', r.engine === 'device' ? 'Made on your device, check before using' : (r.note || '') + '. Made on your device, check before using.')); }
    const c = document.createElement('button'); c.textContent = 'Close'; c.onclick = close; box.append(c); sh.append(st, box); document.documentElement.append(host); c.focus();
    box.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  }
  chrome.runtime.onMessage.addListener((m) => { if (m.type === 'tr.show') show(m.result); });
  addEventListener('mousedown', (e) => { if (host && e.target !== host) close(); }, true);
})();
