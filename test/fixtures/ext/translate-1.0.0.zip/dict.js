/* Offline word and phrase table, English pivot.  Columns: en, es, fr, de, it, pt.  Small on purpose: rough meaning, not literature. */
(function (root) {
  'use strict';
  const L = ['en', 'es', 'fr', 'de', 'it', 'pt'];
  const R = `
hello|hola|bonjour|hallo|ciao|olá
goodbye|adiós|au revoir|auf wiedersehen|arrivederci|adeus
good morning|buenos días|bonjour|guten morgen|buongiorno|bom dia
good evening|buenas tardes|bonsoir|guten abend|buonasera|boa noite
good night|buenas noches|bonne nuit|gute nacht|buonanotte|boa noite
please|por favor|s'il vous plaît|bitte|per favore|por favor
thank you|gracias|merci|danke|grazie|obrigado
thanks|gracias|merci|danke|grazie|obrigado
sorry|lo siento|désolé|entschuldigung|scusa|desculpe
excuse me|perdón|excusez-moi|entschuldigen sie|mi scusi|com licença
yes|sí|oui|ja|sì|sim
no|no|non|nein|no|não
the|el|le|der|il|o
a|un|un|ein|un|um
an|un|un|ein|un|um
and|y|et|und|e|e
or|o|ou|oder|o|ou
but|pero|mais|aber|ma|mas
with|con|avec|mit|con|com
without|sin|sans|ohne|senza|sem
for|para|pour|für|per|para
from|de|de|von|da|de
to|a|à|zu|a|para
in|en|dans|in|in|em
on|sobre|sur|auf|su|sobre
at|en|à|bei|a|em
of|de|de|von|di|de
by|por|par|durch|da|por
about|sobre|à propos de|über|circa|sobre
i|yo|je|ich|io|eu
you|tú|tu|du|tu|você
he|él|il|er|lui|ele
she|ella|elle|sie|lei|ela
we|nosotros|nous|wir|noi|nós
they|ellos|ils|sie|loro|eles
it|ello|il|es|esso|isso
my|mi|mon|mein|mio|meu
your|tu|ton|dein|tuo|seu
our|nuestro|notre|unser|nostro|nosso
this|este|ce|dieses|questo|este
that|ese|cela|das|quello|esse
these|estos|ces|diese|questi|estes
what|qué|quoi|was|cosa|o que
who|quién|qui|wer|chi|quem
where|dónde|où|wo|dove|onde
when|cuándo|quand|wann|quando|quando
why|por qué|pourquoi|warum|perché|por que
how|cómo|comment|wie|come|como
how much|cuánto|combien|wie viel|quanto|quanto
which|cuál|quel|welche|quale|qual
is|es|est|ist|è|é
are|son|sont|sind|sono|são
was|era|était|war|era|era
be|ser|être|sein|essere|ser
have|tener|avoir|haben|avere|ter
has|tiene|a|hat|ha|tem
do|hacer|faire|machen|fare|fazer
does|hace|fait|macht|fa|faz
can|poder|pouvoir|können|potere|poder
will|va a|va|wird|sarà|vai
want|querer|vouloir|wollen|volere|querer
need|necesitar|avoir besoin|brauchen|avere bisogno|precisar
know|saber|savoir|wissen|sapere|saber
see|ver|voir|sehen|vedere|ver
go|ir|aller|gehen|andare|ir
come|venir|venir|kommen|venire|vir
make|hacer|faire|machen|fare|fazer
get|obtener|obtenir|bekommen|ottenere|obter
give|dar|donner|geben|dare|dar
take|tomar|prendre|nehmen|prendere|pegar
use|usar|utiliser|benutzen|usare|usar
find|encontrar|trouver|finden|trovare|encontrar
buy|comprar|acheter|kaufen|comprare|comprar
sell|vender|vendre|verkaufen|vendere|vender
pay|pagar|payer|zahlen|pagare|pagar
send|enviar|envoyer|senden|inviare|enviar
read|leer|lire|lesen|leggere|ler
write|escribir|écrire|schreiben|scrivere|escrever
open|abrir|ouvrir|öffnen|aprire|abrir
close|cerrar|fermer|schließen|chiudere|fechar
save|guardar|enregistrer|speichern|salvare|salvar
help|ayuda|aide|hilfe|aiuto|ajuda
search|buscar|rechercher|suchen|cercare|pesquisar
new|nuevo|nouveau|neu|nuovo|novo
old|viejo|vieux|alt|vecchio|velho
good|bueno|bon|gut|buono|bom
bad|malo|mauvais|schlecht|cattivo|mau
big|grande|grand|groß|grande|grande
small|pequeño|petit|klein|piccolo|pequeno
more|más|plus|mehr|più|mais
less|menos|moins|weniger|meno|menos
all|todo|tout|alle|tutto|tudo
every|cada|chaque|jeder|ogni|cada
some|algunos|quelques|einige|alcuni|alguns
many|muchos|beaucoup|viele|molti|muitos
other|otro|autre|andere|altro|outro
first|primero|premier|erste|primo|primeiro
last|último|dernier|letzte|ultimo|último
next|siguiente|prochain|nächste|prossimo|próximo
free|gratis|gratuit|kostenlos|gratis|grátis
now|ahora|maintenant|jetzt|ora|agora
today|hoy|aujourd'hui|heute|oggi|hoje
tomorrow|mañana|demain|morgen|domani|amanhã
yesterday|ayer|hier|gestern|ieri|ontem
here|aquí|ici|hier|qui|aqui
there|allí|là|dort|lì|lá
always|siempre|toujours|immer|sempre|sempre
never|nunca|jamais|nie|mai|nunca
very|muy|très|sehr|molto|muito
also|también|aussi|auch|anche|também
only|solo|seulement|nur|solo|só
not|no|ne pas|nicht|non|não
day|día|jour|tag|giorno|dia
week|semana|semaine|woche|settimana|semana
month|mes|mois|monat|mese|mês
year|año|an|jahr|anno|ano
time|tiempo|temps|zeit|tempo|tempo
hour|hora|heure|stunde|ora|hora
minute|minuto|minute|minute|minuto|minuto
name|nombre|nom|name|nome|nome
person|persona|personne|person|persona|pessoa
people|gente|gens|leute|gente|pessoas
man|hombre|homme|mann|uomo|homem
woman|mujer|femme|frau|donna|mulher
child|niño|enfant|kind|bambino|criança
friend|amigo|ami|freund|amico|amigo
family|familia|famille|familie|famiglia|família
house|casa|maison|haus|casa|casa
home|hogar|maison|zuhause|casa|lar
city|ciudad|ville|stadt|città|cidade
country|país|pays|land|paese|país
world|mundo|monde|welt|mondo|mundo
work|trabajo|travail|arbeit|lavoro|trabalho
company|empresa|entreprise|firma|azienda|empresa
money|dinero|argent|geld|denaro|dinheiro
price|precio|prix|preis|prezzo|preço
cost|costo|coût|kosten|costo|custo
order|pedido|commande|bestellung|ordine|pedido
product|producto|produit|produkt|prodotto|produto
service|servicio|service|dienst|servizio|serviço
shop|tienda|boutique|laden|negozio|loja
store|tienda|magasin|geschäft|negozio|loja
market|mercado|marché|markt|mercato|mercado
food|comida|nourriture|essen|cibo|comida
water|agua|eau|wasser|acqua|água
coffee|café|café|kaffee|caffè|café
tea|té|thé|tee|tè|chá
bread|pan|pain|brot|pane|pão
table|mesa|table|tisch|tavolo|mesa
room|habitación|chambre|zimmer|camera|quarto
hotel|hotel|hôtel|hotel|albergo|hotel
restaurant|restaurante|restaurant|restaurant|ristorante|restaurante
station|estación|gare|bahnhof|stazione|estação
train|tren|train|zug|treno|trem
bus|autobús|bus|bus|autobus|ônibus
car|coche|voiture|auto|macchina|carro
airport|aeropuerto|aéroport|flughafen|aeroporto|aeroporto
ticket|billete|billet|fahrkarte|biglietto|bilhete
street|calle|rue|straße|strada|rua
left|izquierda|gauche|links|sinistra|esquerda
right|derecha|droite|rechts|destra|direita
straight|recto|tout droit|geradeaus|dritto|em frente
toilet|baño|toilettes|toilette|bagno|banheiro
doctor|médico|médecin|arzt|medico|médico
hospital|hospital|hôpital|krankenhaus|ospedale|hospital
email|correo|courriel|e-mail|email|email
message|mensaje|message|nachricht|messaggio|mensagem
phone|teléfono|téléphone|telefon|telefono|telefone
page|página|page|seite|pagina|página
link|enlace|lien|link|collegamento|link
file|archivo|fichier|datei|file|arquivo
password|contraseña|mot de passe|passwort|password|senha
account|cuenta|compte|konto|account|conta
settings|ajustes|paramètres|einstellungen|impostazioni|configurações
privacy|privacidad|confidentialité|datenschutz|privacy|privacidade
error|error|erreur|fehler|errore|erro
delete|eliminar|supprimer|löschen|eliminare|excluir
cancel|cancelar|annuler|abbrechen|annullare|cancelar
continue|continuar|continuer|weiter|continua|continuar
back|atrás|retour|zurück|indietro|voltar
welcome|bienvenido|bienvenue|willkommen|benvenuto|bem-vindo
love|amor|amour|liebe|amore|amor
happy|feliz|heureux|glücklich|felice|feliz
beautiful|hermoso|beau|schön|bello|bonito
delicious|delicioso|délicieux|lecker|delizioso|delicioso
sale|oferta|solde|angebot|saldo|promoção
discount|descuento|remise|rabatt|sconto|desconto
delivery|entrega|livraison|lieferung|consegna|entrega
shipping|envío|expédition|versand|spedizione|envio
return|devolución|retour|rückgabe|reso|devolução
size|talla|taille|größe|taglia|tamanho
colour|color|couleur|farbe|colore|cor
color|color|couleur|farbe|colore|cor
red|rojo|rouge|rot|rosso|vermelho
blue|azul|bleu|blau|blu|azul
green|verde|vert|grün|verde|verde
black|negro|noir|schwarz|nero|preto
white|blanco|blanc|weiß|bianco|branco
one|uno|un|eins|uno|um
two|dos|deux|zwei|due|dois
three|tres|trois|drei|tre|três
four|cuatro|quatre|vier|quattro|quatro
five|cinco|cinq|fünf|cinque|cinco
ten|diez|dix|zehn|dieci|dez
`;
  const rows = R.trim().split('\n').map((l) => l.split('|'));
  const T = {};   // T['en>es'] = {'thank you':'gracias'}, and T['es>en'] for the way back
  L.forEach((a) => L.forEach((b) => { if (a !== b) T[a + '>' + b] = {}; }));
  for (const r of rows) {
    if (r.length !== 6) continue;
    for (let i = 0; i < 6; i++) for (let j = 0; j < 6; j++) {
      if (i === j) continue;
      const k = L[i] + '>' + L[j], from = r[i].toLowerCase();
      /* first row wins, so the more common sense of a word is kept */
      if (!(from in T[k])) T[k][from] = r[j];
    }
  }
  const NAMES = { en: 'English', es: 'Spanish', fr: 'French', de: 'German', it: 'Italian', pt: 'Portuguese' };
  /* common words that give a language away */
  const STOP = {
    en: 'the and of to in is you that it for with was on are as this have not but be at they we your from'.split(' '),
    es: 'el la los las de que y en un una es por con para no se su al lo como más pero sus le ya o este'.split(' '),
    fr: 'le la les de des et en un une est que pour dans qui pas sur au avec ce il elle nous vous mais ou'.split(' '),
    de: 'der die das und ist nicht ein eine zu den mit von sie auf für ich es dem im auch aber wir oder'.split(' '),
    it: 'il lo la gli le di che e un una è per con non si sono da come ma più del della nel anche questo'.split(' '),
    pt: 'o a os as de que e um uma é para com não se por mais como mas foi ao do da em você isso também'.split(' '),
  };
  root.MFDict = { LANGS: L, NAMES, TABLE: T, STOP };
  if (typeof module === 'object' && module.exports) module.exports = root.MFDict;
})(typeof globalThis !== 'undefined' ? globalThis : this);
