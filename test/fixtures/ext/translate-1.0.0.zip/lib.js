/* Translate selection: language guess and an offline word/phrase translator.  No network, no download. */
(function (root, factory) {
  const D = (typeof module === 'object' && module.exports) ? require('./dict.js') : root.MFDict;
  const a = factory(D); if (typeof module === 'object' && module.exports) module.exports = a; root.MFTr = a;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (D) {
  'use strict';
  const tokenize = (s) => String(s).match(/[\p{L}\p{M}'’-]+|\d+(?:[.,]\d+)?|\s+|[^\s]/gu) || [];
  const isWord = (t) => /^[\p{L}\p{M}]/u.test(t);
  const norm = (t) => t.toLowerCase().replace(/’/g, "'");

  /* returns {lang, score, sure}; 'und' if there is too little text */
  function detectLang(text) {
    const words = (String(text).toLowerCase().match(/[\p{L}']+/gu) || []).slice(0, 400);
    if (words.length < 2) return { lang: 'und', score: 0, sure: false };
    const sc = {}; let best = 'und', bs = 0, second = 0;
    for (const l of D.LANGS) { const set = new Set(D.STOP[l]); sc[l] = words.filter((w) => set.has(w)).length / words.length; }
    for (const l of D.LANGS) { if (sc[l] > bs) { second = bs; bs = sc[l]; best = l; } else if (sc[l] > second) second = sc[l]; }
    return bs < 0.08 ? { lang: 'und', score: bs, sure: false } : { lang: best, score: bs, sure: bs - second > 0.05 };
  }

  /* English plural / verb endings: try the plain form when the word is not in the table */
  function stems(w, lang) {
    const out = [w];
    if (lang === 'en') { if (w.endsWith('ies')) out.push(w.slice(0, -3) + 'y'); if (w.endsWith('es')) out.push(w.slice(0, -2)); if (w.endsWith('s')) out.push(w.slice(0, -1)); if (w.endsWith('ing')) out.push(w.slice(0, -3)); if (w.endsWith('ed')) out.push(w.slice(0, -2)); }
    else if (w.endsWith('s') || w.endsWith('x')) out.push(w.slice(0, -1));
    return out;
  }
  function matchCase(src, out) {
    if (src.length > 1 && src === src.toUpperCase()) return out.toUpperCase();
    return src[0] === src[0].toUpperCase() && src[0] !== src[0].toLowerCase() ? out[0].toUpperCase() + out.slice(1) : out;
  }

  /* Word by word with phrases of up to three words.  Pivot through English when no direct table exists. */
  function translate(text, from, to) {
    if (!D.LANGS.includes(to)) return { error: 'Unknown language' };
    if (!D.LANGS.includes(from)) return { error: 'Could not tell the language. Choose it.' };
    if (from === to) return { text: String(text), known: 0, total: 0, confidence: 1, from, to };
    const tab = D.TABLE[from + '>' + to];
    const toks = tokenize(String(text).slice(0, 5000)); let out = '', known = 0, total = 0;
    for (let i = 0; i < toks.length;) {
      if (!isWord(toks[i])) { out += toks[i]; i++; continue; }
      let done = false;
      for (let n = 3; n >= 1 && !done; n--) {
        const parts = []; let j = i;
        while (j < toks.length && parts.length < n) { if (isWord(toks[j])) parts.push(toks[j]); else if (/^\s+$/.test(toks[j])) { /* allowed gap */ } else break; j++; }
        if (parts.length < n) continue;
        const key = parts.map(norm).join(' ');
        let hit = tab[key];
        if (!hit && n === 1) for (const s of stems(key, from)) if (tab[s]) { hit = tab[s]; break; }
        if (hit) { out += matchCase(parts[0], hit); known += n; total += n; i = j; done = true; }
      }
      if (!done) { out += toks[i]; total++; i++; }
    }
    return { text: out, known, total, confidence: total ? known / total : 1, from, to };
  }
  const label = (r) => r.total && r.confidence < 0.5 ? 'Only part of this could be translated' : 'Rough word by word translation';
  return { tokenize, detectLang, translate, label, LANGS: D.LANGS, NAMES: D.NAMES };
});
