/* Used by the background and the popup: on-device model first (when Mayfair provides one), the offline table otherwise. */
async function translateText(text, from, to) {
  const ai = MFX.localai();
  let f = from;
  if (!f || f === 'auto') { const d = MFTr.detectLang(text); f = d.lang === 'und' ? (to === 'en' ? 'es' : 'en') : d.lang; if (d.lang === 'und' && to !== 'en') f = 'en'; }
  if (ai.has('translate')) {
    try { const r = await ai.run('translate', text, { from: f, to }); if (r && r.ok !== false && typeof (r.text || r) === 'string') return { text: r.text || r, from: f, to, engine: 'device', confidence: 1 }; } catch { /* fall through */ }
  }
  const r = MFTr.translate(text, f, to); if (r.error) return r;
  return Object.assign(r, { engine: 'table', note: MFTr.label(r) });
}
