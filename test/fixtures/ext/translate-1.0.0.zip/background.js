importScripts('mf.js', 'dict.js', 'lib.js', 'service.js');
const opts = async () => Object.assign({ to: 'en' }, await MFX.store.get('tr.opts', {}));
async function run(tabId, text) {
  const o = await opts(), r = await translateText(String(text || '').trim(), 'auto', o.to);
  if (!r.error) r.names = MFTr.NAMES;
  chrome.tabs.sendMessage(tabId, { type: 'tr.show', result: text ? r : { error: 'Select some text first' } }).catch(() => {});
}
chrome.runtime.onInstalled.addListener(() => chrome.contextMenus.create({ id: 'tr', title: 'Translate selection', contexts: ['selection'] }));
chrome.contextMenus.onClicked.addListener((i, t) => { if (i.menuItemId === 'tr' && t) run(t.id, i.selectionText); });
chrome.commands.onCommand.addListener(async (c) => {
  if (c !== 'translate') return; const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!t) return;
  let txt = ''; try { const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => String(getSelection()) }); txt = r.result; } catch { /* restricted */ }
  run(t.id, txt);
});
