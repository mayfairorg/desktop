const $ = (id) => document.getElementById(id);
$('from').innerHTML = '<option value="auto">Detect</option>' + MFTr.LANGS.map((l) => '<option value="' + l + '">' + MFTr.NAMES[l] + '</option>').join('');
$('to').innerHTML = MFTr.LANGS.map((l) => '<option value="' + l + '">' + MFTr.NAMES[l] + '</option>').join('');
(async () => {
  const o = Object.assign({ to: 'en' }, await MFX.store.get('tr.opts', {})); $('to').value = o.to;
  try { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => String(getSelection()) }); if (r.result) $('in').value = r.result.slice(0, 2000); } catch { /* no selection available */ }
  if ($('in').value) go();
})();
async function go() {
  const t = $('in').value.trim(); const out = $('out');
  if (!t) { out.innerHTML = '<div class="empty"><b>Nothing to translate</b>Type or paste text, or select text on a page first.</div>'; return; }
  const r = await translateText(t, $('from').value, $('to').value);
  if (r.error) { out.innerHTML = '<p class="err">' + MFX.esc(r.error) + '</p>'; return; }
  out.innerHTML = '<div class="card" style="margin:0"><div class="note">' + MFTr.NAMES[r.from] + ' to ' + MFTr.NAMES[r.to] + '</div><div style="white-space:pre-wrap;font-size:15px" id="res"></div><p class="note" style="margin:8px 0 0">' + MFX.esc((r.note ? r.note + '. ' : '') + 'Made on your device, check before using.') + '</p></div><div class="bar" style="margin-top:8px"><button class="btn sm" id="cp">Copy</button></div>';
  $('res').textContent = r.text; $('cp').onclick = async () => { await navigator.clipboard.writeText(r.text).catch(() => {}); $('cp').textContent = 'Copied'; };
}
$('go').onclick = go;
