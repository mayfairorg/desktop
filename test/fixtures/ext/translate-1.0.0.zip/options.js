const $ = (id) => document.getElementById(id);
$('to').innerHTML = MFDict.LANGS.map((l) => '<option value="' + l + '">' + MFDict.NAMES[l] + '</option>').join('');
MFX.store.get('tr.opts', { to: 'en' }).then((o) => $('to').value = o.to);
$('to').onchange = async () => { await MFX.store.set('tr.opts', { to: $('to').value }); $('msg').textContent = 'Saved'; };
