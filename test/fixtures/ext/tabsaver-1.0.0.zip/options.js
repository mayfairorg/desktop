const $ = (id) => document.getElementById(id), S = MFX.store, T = MFTabs;
(async () => {
  const o = Object.assign({ auto: true, everyMin: 30, keep: 5 }, await S.get('tabs.opts', {}));
  $('auto').checked = o.auto; $('every').value = String(o.everyMin); $('keep').value = o.keep;
  const save = () => S.set('tabs.opts', { auto: $('auto').checked, everyMin: +$('every').value, keep: MFX.clamp(+$('keep').value || 5, 1, 20) });
  ['auto', 'every', 'keep'].forEach((k) => $(k).addEventListener('change', save));
  $('exp').onclick = async () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([T.exportJson(await S.get('tabs.sessions', []))], { type: 'application/json' })); a.download = 'mayfair-tabs.json'; a.click(); };
  $('imp').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return; const r = T.importJson(await f.text());
    $('msg').className = 'note ' + (r.error ? 'err' : 'ok');
    if (r.error) { $('msg').textContent = r.error; return; }
    await S.set('tabs.sessions', T.merge(await S.get('tabs.sessions', []), r.sessions)); $('msg').textContent = 'Added ' + r.sessions.length + ' sessions';
  };
})();
