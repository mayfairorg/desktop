/* Tab saver: pure logic. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFTabs = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const isWeb = (u) => /^https?:\/\//i.test(String(u || ''));
  const TRACK = /^(utm_|fbclid$|gclid$|mc_cid$|mc_eid$|igshid$)/i;
  function normUrl(u) {
    try { const x = new URL(u); x.hash = ''; [...x.searchParams.keys()].forEach((k) => { if (TRACK.test(k)) x.searchParams.delete(k); }); let s = x.href; if (x.pathname !== '/' ) s = s.replace(/\/(\?|$)/, '$1'); return s; } catch { return String(u); }
  }
  function dedupe(tabs) { const seen = new Set(); return tabs.filter((t) => { const k = normUrl(t.url); if (seen.has(k)) return false; seen.add(k); return true; }); }
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function defaultName(now) { const d = new Date(now); return 'Saved ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ', ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  /* tabs: [{url,title,pinned}] from chrome.tabs.query */
  function makeSession(tabs, name, now, kind) {
    const keep = dedupe((tabs || []).filter((t) => isWeb(t.url))).map((t) => ({ url: t.url, title: String(t.title || t.url).slice(0, 200), pinned: !!t.pinned }));
    if (!keep.length) return { error: 'No web pages to save in this window' };
    return { session: { id: 's' + now.toString(36) + Math.random().toString(36).slice(2, 5), name: String(name || '').trim().slice(0, 80) || defaultName(now), t: now, kind: kind === 'auto' ? 'auto' : 'manual', tabs: keep } };
  }
  /* newest first; auto snapshots are trimmed to `keep`, saved sessions are never dropped */
  function trimAuto(sessions, keep) {
    let n = 0; return sessions.slice().sort((a, b) => b.t - a.t).filter((s) => s.kind !== 'auto' || ++n <= keep);
  }
  function groupByHost(tabs) {
    const m = new Map(); for (const t of tabs) { let h = ''; try { h = new URL(t.url).hostname.replace(/^www\./, ''); } catch { /* skip */ } if (!m.has(h)) m.set(h, []); m.get(h).push(t); }
    return [...m].map(([host, tabs]) => ({ host, tabs })).sort((a, b) => b.tabs.length - a.tabs.length || a.host.localeCompare(b.host));
  }
  function search(sessions, q) {
    q = String(q || '').trim().toLowerCase(); if (!q) return sessions;
    return sessions.filter((s) => s.name.toLowerCase().includes(q) || s.tabs.some((t) => (t.title + ' ' + t.url).toLowerCase().includes(q)));
  }
  const exportJson = (sessions) => JSON.stringify({ mayfairTabs: 1, sessions }, null, 2);
  function importJson(text) {
    let j; try { j = JSON.parse(text); } catch { return { error: 'That is not a saved tabs file' }; }
    if (!j || j.mayfairTabs !== 1 || !Array.isArray(j.sessions)) return { error: 'That is not a saved tabs file' };
    const out = [];
    for (const s of j.sessions.slice(0, 500)) {
      if (!s || !Array.isArray(s.tabs)) continue;
      const tabs = s.tabs.filter((t) => t && isWeb(t.url)).slice(0, 500).map((t) => ({ url: String(t.url), title: String(t.title || t.url).slice(0, 200), pinned: !!t.pinned }));
      if (tabs.length) out.push({ id: String(s.id || 'i' + out.length + Date.now().toString(36)).slice(0, 40), name: String(s.name || 'Imported').slice(0, 80), t: +s.t || Date.now(), kind: 'manual', tabs });
    }
    return out.length ? { sessions: out } : { error: 'Nothing to import' };
  }
  function merge(existing, incoming) { const ids = new Set(existing.map((s) => s.id)); return existing.concat(incoming.filter((s) => !ids.has(s.id))).sort((a, b) => b.t - a.t); }
  return { isWeb, normUrl, dedupe, defaultName, makeSession, trimAuto, groupByHost, search, exportJson, importJson, merge };
});
