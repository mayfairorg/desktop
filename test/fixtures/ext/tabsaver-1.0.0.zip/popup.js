const $ = (id) => document.getElementById(id), T = MFTabs, S = MFX.store; let list = [], win;
async function load() { list = await S.get('tabs.sessions', []); draw(); }
function draw() {
  const l = T.search(list, $('q').value);
  $('list').innerHTML = l.length ? l.map((s) => '<div class="row"><div class="grow"><b>' + MFX.esc(s.name) + '</b><small>' + s.tabs.length + ' tabs · ' + MFX.ago(s.t) + (s.kind === 'auto' ? ' · automatic' : '') + '</small></div>' +
    '<button class="btn sm" data-a="open" data-id="' + s.id + '" aria-label="Open ' + MFX.esc(s.name) + ' in a new window">Open</button><button class="btn sm danger" data-a="del" data-id="' + s.id + '" aria-label="Delete ' + MFX.esc(s.name) + '">Delete</button></div>').join('')
    : '<div class="empty"><b>' + (list.length ? 'No match' : 'Nothing saved yet') + '</b>' + (list.length ? 'Try other words.' : 'Save this window to get started.') + '</div>';
}
$('q').oninput = draw;
$('f').onsubmit = async (e) => {
  e.preventDefault();
  const tabs = await chrome.tabs.query({ windowId: win.id }), r = T.makeSession(tabs, $('name').value, Date.now(), 'manual');
  $('msg').className = 'note ' + (r.error ? 'err' : 'ok');
  if (r.error) { $('msg').textContent = r.error; return; }
  await S.set('tabs.sessions', [r.session].concat(await S.get('tabs.sessions', [])));
  $('msg').textContent = 'Saved ' + r.session.tabs.length + ' tabs'; $('name').value = '';
  if ($('close').checked) { const ids = tabs.filter((t) => !t.pinned && T.isWeb(t.url)).map((t) => t.id); const keep = tabs.length - ids.length; if (!keep) await chrome.tabs.create({ windowId: win.id, url: 'chrome://newtab' }).catch(() => {}); chrome.tabs.remove(ids); }
  load();
};
$('list').onclick = async (e) => {
  const b = e.target.closest('button'); if (!b) return; const s = list.find((x) => x.id === b.dataset.id); if (!s) return;
  if (b.dataset.a === 'del') { list = list.filter((x) => x.id !== s.id); await S.set('tabs.sessions', list); draw(); return; }
  const w = await chrome.windows.create({ url: s.tabs[0].url }); const first = w.tabs[0];
  if (s.tabs[0].pinned) chrome.tabs.update(first.id, { pinned: true });
  for (const t of s.tabs.slice(1)) await chrome.tabs.create({ windowId: w.id, url: t.url, pinned: t.pinned, active: false });
};
(async () => { win = await chrome.windows.getCurrent(); const n = (await chrome.tabs.query({ windowId: win.id })).length; $('count').textContent = n + ' tabs open'; load(); })();
