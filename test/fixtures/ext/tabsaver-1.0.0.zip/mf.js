/* Mayfair extension helpers shared by every extension (copied into each one by tools/build.mjs sync).
   UMD: a classic script in pages and service workers (importScripts), a CommonJS module in node tests. */
(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.MFX = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  const MAYFAIR_ORIGINS = ['https://cloud.mayfairmail.com', 'https://mayfairmail.com'];
  const MSG = {
    HELLO: 'mf.ext.hello', CLIP: 'mf.clip', CLIP_ACK: 'mf.clip.ack',
    PW_REQ: 'mf.pw.request', PW_RES: 'mf.pw.credentials',
  };

  const isMayfairOrigin = (o) => MAYFAIR_ORIGINS.includes(String(o || ''));

  let seq = 0;
  /* the one message shape that crosses the page bridge, in both directions */
  function envelope(type, payload, id) {
    return { mayfair: 1, v: 1, type: String(type), id: id || ('x' + Date.now().toString(36) + (++seq)), payload: payload === undefined ? null : payload };
  }
  function validEnvelope(m) {
    return !!m && typeof m === 'object' && m.mayfair === 1 && m.v === 1 && typeof m.type === 'string' && m.type.startsWith('mf.') && typeof m.id === 'string' && m.id.length <= 64;
  }

  /* host helpers */
  function hostOf(url) { try { return new URL(url).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; } }
  function domainMatches(host, domain) {
    host = String(host || '').toLowerCase(); domain = String(domain || '').toLowerCase().replace(/^\*?\.?/, '');
    return !!domain && (host === domain || host.endsWith('.' + domain));
  }
  function isHttp(url) { try { const p = new URL(url).protocol; return p === 'http:' || p === 'https:'; } catch { return false; } }

  /* storage: chrome.storage.local with a plain in-memory fallback so pages never throw */
  const mem = {};
  const hasChrome = () => typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const store = {
    async get(key, def) {
      if (hasChrome()) { const r = await chrome.storage.local.get(key); return r[key] === undefined ? def : r[key]; }
      return mem[key] === undefined ? def : mem[key];
    },
    async set(key, val) { if (hasChrome()) await chrome.storage.local.set({ [key]: val }); else mem[key] = val; },
    async del(key) { if (hasChrome()) await chrome.storage.local.remove(key); else delete mem[key]; },
  };

  /* On-device AI stub (policy: code against MF.localai, never ask for a download).  Returns 'not-installed' until the
     Mayfair core loader is present on the page; extensions fall back to their own classic algorithm. */
  const NOT = Object.freeze({ ok: false, reason: 'not-installed' });
  function localai() {
    const l = root.MF && root.MF.localai;
    if (l && typeof l.has === 'function') return l;
    return { has: () => false, ensure: () => Promise.resolve(NOT), run: () => Promise.resolve(NOT), remove: () => Promise.resolve(true) };
  }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }
  function fmtMoney(n, cur) {
    if (!isFinite(n)) return '';
    try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur || 'USD' }).format(n); } catch { return (cur ? cur + ' ' : '') + n.toFixed(2); }
  }
  function ago(ts, now) {
    const s = Math.max(0, ((now || Date.now()) - ts) / 1000);
    if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago'; return Math.floor(s / 86400) + ' d ago';
  }

  return { MAYFAIR_ORIGINS, MSG, isMayfairOrigin, envelope, validEnvelope, hostOf, domainMatches, isHttp, store, localai, esc, clamp, fmtMoney, ago };
});
