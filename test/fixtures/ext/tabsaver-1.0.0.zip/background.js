importScripts('mf.js', 'lib.js');
const T = MFTabs, S = MFX.store;
const O = async () => Object.assign({ auto: true, everyMin: 30, keep: 5 }, await S.get('tabs.opts', {}));
async function autosave() {
  const o = await O(); if (!o.auto) return;
  const wins = await chrome.windows.getAll({ populate: true, windowTypes: ['normal'] });
  const all = wins.flatMap((w) => w.tabs || []); const r = T.makeSession(all, 'Automatic snapshot ' + T.defaultName(Date.now()).slice(6), Date.now(), 'auto'); if (r.error) return;
  const list = await S.get('tabs.sessions', []);
  const last = list.find((s) => s.kind === 'auto');
  if (last && last.tabs.map((t) => t.url).join('\n') === r.session.tabs.map((t) => t.url).join('\n')) return;   // nothing changed
  await S.set('tabs.sessions', T.trimAuto([r.session].concat(list), o.keep));
}
async function schedule() { const o = await O(); chrome.alarms.create('tabs.auto', { periodInMinutes: Math.max(5, o.everyMin) }); }
chrome.runtime.onInstalled.addListener(schedule); chrome.runtime.onStartup.addListener(schedule);
chrome.storage.onChanged.addListener((c) => { if (c['tabs.opts']) schedule(); });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'tabs.auto') autosave(); });
