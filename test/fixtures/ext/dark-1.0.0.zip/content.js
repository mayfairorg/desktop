/* Runs at document start so the page never flashes white.  Reads one small settings object, adds or removes one style element. */
(function () {
  if (window.top !== window) return;   // the filter on <html> covers frames
  const D = globalThis.MFDark, ID = 'mf-dark-style'; let s = D.clean(); let settled = false;
  const host = location.hostname;
  const set = (on) => {
    let el = document.getElementById(ID);
    if (on && !el) { el = document.createElement('style'); el.id = ID; el.textContent = D.css(s); (document.head || document.documentElement).append(el); }
    else if (on && el) el.textContent = D.css(s);
    else if (!on && el) el.remove();
  };
  const dark = () => D.pageIsDark([getComputedStyle(document.documentElement).backgroundColor, document.body ? getComputedStyle(document.body).backgroundColor : '']);
  function decide() {
    const m = D.modeFor(s, host);
    if (m !== 'auto') return set(m === 'on');
    if (!settled) return set(true);               // assume light until the page has painted, to avoid a flash
    const el = document.getElementById(ID); if (el) el.remove();
    set(D.shouldApply(s, host, dark()));
  }
  chrome.storage.local.get('dark.settings').then((r) => { s = D.clean(r['dark.settings']); decide(); });
  chrome.storage.onChanged.addListener((c) => { if (c['dark.settings']) { s = D.clean(c['dark.settings'].newValue); decide(); } });
  const done = () => { settled = true; decide(); };
  if (document.readyState === 'complete') done(); else addEventListener('load', () => setTimeout(done, 50), { once: true });
  chrome.runtime.onMessage.addListener((m, _s, reply) => { if (m.type === 'dark.state') reply({ host, mode: D.modeFor(s, host), applied: !!document.getElementById(ID), alreadyDark: settled ? (document.getElementById(ID) ? null : dark()) : null }); });
})();
