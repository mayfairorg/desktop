importScripts('lib.js');
chrome.commands.onCommand.addListener(async (c) => {
  if (c !== 'toggle-dark') return;
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!t || !/^https?:/.test(t.url || '')) return;
  const host = new URL(t.url).hostname, key = 'dark.settings';
  const D = MFDark; const s = D.clean((await chrome.storage.local.get(key))[key]);
  const st = await chrome.tabs.sendMessage(t.id, { type: 'dark.state' }).catch(() => null);
  const next = st && st.applied ? 'off' : 'on';
  await chrome.storage.local.set({ [key]: D.setSite(s, host, next) });
});
