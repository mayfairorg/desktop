/* Dark mode for any site: pure logic. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFDark = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DEFAULTS = { mode: 'auto', brightness: 100, contrast: 100, sites: {} };   // mode: off | on | auto (skip pages that are already dark)

  function parseColor(s) {
    s = String(s || '').trim().toLowerCase();
    if (!s || s === 'transparent') return null;
    let m = /^#([0-9a-f]{3,8})$/.exec(s);
    if (m) { let h = m[1]; if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join(''); if (h.length !== 6 && h.length !== 8) return null; const a = h.length === 8 ? parseInt(h.slice(6), 16) / 255 : 1; return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a }; }
    m = /^rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(s);
    if (m) { let a = m[4] == null ? 1 : m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]); return { r: +m[1], g: +m[2], b: +m[3], a }; }
    return null;
  }
  /* WCAG relative luminance, 0 (black) to 1 (white) */
  function luminance(c) {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  /* page is already dark when its canvas colour is opaque-ish and dim.  `colors` = [html bg, body bg] computed styles. */
  function pageIsDark(colors) {
    for (let i = colors.length - 1; i >= 0; i--) {
      const c = parseColor(colors[i]);
      if (c && c.a > 0.5) return luminance(c) < 0.18;
    }
    return false;   // nothing painted: the browser default is white
  }
  const normHost = (h) => String(h || '').toLowerCase().replace(/^www\./, '');
  function clean(s) {
    s = Object.assign({}, DEFAULTS, s || {});
    s.mode = ['off', 'on', 'auto'].includes(s.mode) ? s.mode : 'auto';
    s.brightness = Math.min(150, Math.max(50, +s.brightness || 100)); s.contrast = Math.min(150, Math.max(50, +s.contrast || 100));
    const sites = {}; for (const [k, v] of Object.entries(s.sites || {})) if (v === 'on' || v === 'off') sites[normHost(k)] = v;
    s.sites = sites; return s;
  }
  function modeFor(s, host) { const o = clean(s); return o.sites[normHost(host)] || o.mode; }
  /* should the dark filter be on right now */
  function shouldApply(s, host, alreadyDark) {
    const m = modeFor(s, host);
    return m === 'on' || (m === 'auto' && !alreadyDark);
  }
  function setSite(s, host, mode) {
    const o = clean(s), h = normHost(host); if (!h) return o;
    if (mode === 'on' || mode === 'off') o.sites[h] = mode; else delete o.sites[h];
    return o;
  }
  /* invert the page, rotate hue back so colours keep their meaning, then put media the right way round again */
  function css(s) {
    const o = clean(s);
    return 'html{background:#fff!important;filter:invert(1) hue-rotate(180deg) brightness(' + o.brightness + '%) contrast(' + o.contrast + '%)!important;color-scheme:dark!important}' +
      'img,picture,video,canvas,iframe,embed,object,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}' +
      'img[src$=".svg"],img[src*=".svg?"]{filter:none!important}';
  }
  return { DEFAULTS, parseColor, luminance, pageIsDark, clean, modeFor, shouldApply, setSite, css, normHost };
});
