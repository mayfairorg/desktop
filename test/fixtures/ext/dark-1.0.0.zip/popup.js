const $ = (id) => document.getElementById(id), D = MFDark, K = 'dark.settings'; let s, tab, host;
const save = () => chrome.storage.local.set({ [K]: s });
async function show() {
  const st = await chrome.tabs.sendMessage(tab.id, { type: 'dark.state' }).catch(() => null);
  const m = D.modeFor(s, host);
  $('on').checked = st ? st.applied : m === 'on';
  $('why').textContent = m === 'auto' ? (st && !st.applied && st.alreadyDark ? 'This page is already dark, so it is left alone.' : 'Automatic: dark unless the page is already dark.') : m === 'on' ? 'Always dark on this site.' : 'Always light on this site.';
  $('br').value = s.brightness; $('ct').value = s.contrast; $('bo').textContent = s.brightness + '%'; $('co').textContent = s.contrast + '%';
}
(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || '')) { document.body.innerHTML = '<div class="pop"><div class="empty"><b>Not available here</b>Open a website.</div></div>'; return; }
  host = new URL(tab.url).hostname; $('host').textContent = D.normHost(host);
  s = D.clean((await chrome.storage.local.get(K))[K]);
  $('on').onchange = async () => { s = D.setSite(s, host, $('on').checked ? 'on' : 'off'); await save(); setTimeout(show, 150); };
  $('auto').onclick = async () => { s = D.setSite(s, host, null); await save(); setTimeout(show, 300); };
  $('br').oninput = $('ct').oninput = async () => { s.brightness = +$('br').value; s.contrast = +$('ct').value; s = D.clean(s); await save(); $('bo').textContent = s.brightness + '%'; $('co').textContent = s.contrast + '%'; };
  show();
})();
