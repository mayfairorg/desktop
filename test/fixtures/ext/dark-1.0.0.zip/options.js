const $ = (id) => document.getElementById(id), D = MFDark, K = 'dark.settings'; let s;
const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function draw() {
  $('mode').value = s.mode; const h = Object.keys(s.sites).sort();
  $('sites').innerHTML = h.length ? h.map((x) => '<div class="row"><div class="grow"><b>' + esc(x) + '</b><small>' + (s.sites[x] === 'on' ? 'Always dark' : 'Always light') + '</small></div><button class="btn sm" data-h="' + esc(x) + '" aria-label="Forget ' + esc(x) + '">Forget</button></div>').join('') : '<div class="empty"><b>Nothing set yet</b>Use the toolbar button on a site to choose for that site.</div>';
}
$('mode').onchange = async () => { s = D.clean(Object.assign({}, s, { mode: $('mode').value })); await chrome.storage.local.set({ [K]: s }); };
$('sites').onclick = async (e) => { const b = e.target.closest('[data-h]'); if (!b) return; s = D.setSite(s, b.dataset.h, null); await chrome.storage.local.set({ [K]: s }); draw(); };
chrome.storage.local.get(K).then((r) => { s = D.clean(r[K]); draw(); });
