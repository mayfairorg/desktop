/* Tracker blocker: pure logic.  Builds declarativeNetRequest rules from the bundled list. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFBlock = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const DOMAIN = /^(?=.{3,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;
  const TYPES = ['script', 'image', 'xmlhttprequest', 'sub_frame', 'ping', 'media', 'stylesheet', 'font', 'websocket', 'other'];

  function parseList(text) {
    const seen = new Set(), out = [], bad = [];
    String(text).split(/\r?\n/).forEach((l, i) => {
      l = l.replace(/#.*/, '').trim().toLowerCase(); if (!l) return;
      if (!DOMAIN.test(l)) { bad.push({ line: i + 1, text: l }); return; }
      if (!seen.has(l)) { seen.add(l); out.push(l); }
    });
    return { domains: out, bad };
  }
  /* a domain is dropped when a shorter parent domain is already in the list (it covers the subdomain) */
  function dedupeParents(domains) {
    const set = new Set(domains);
    return domains.filter((d) => { const p = d.split('.'); for (let i = 1; i < p.length - 1; i++) if (set.has(p.slice(i).join('.'))) return false; return true; });
  }
  function buildRules(domains, startId) {
    let id = startId || 1;
    return domains.map((d) => ({ id: id++, priority: 1, action: { type: 'block' }, condition: { urlFilter: '||' + d + '^', domainType: 'thirdParty', resourceTypes: TYPES } }));
  }
  /* "turn off on this site" = let the page and everything it loads through */
  const ALLOW_BASE = 100000;
  function allowRule(host, id) { return { id, priority: 10, action: { type: 'allowAllRequests' }, condition: { requestDomains: [host], resourceTypes: ['main_frame', 'sub_frame'] } }; }
  function allowRules(sites) { return (sites || []).map((h, i) => allowRule(h, ALLOW_BASE + i)); }
  const normHost = (h) => String(h || '').toLowerCase().replace(/^www\./, '');
  function toggleSite(sites, host, off) { const h = normHost(host), s = (sites || []).filter((x) => x !== h); if (off && h) s.push(h); return s.sort(); }
  function validateRules(rules, max) {
    const ids = new Set(); const errs = [];
    if (rules.length > (max || 30000)) errs.push('too many rules');
    for (const r of rules) {
      if (ids.has(r.id)) errs.push('duplicate id ' + r.id); ids.add(r.id);
      if (!r.condition || !r.condition.urlFilter || !/^\|\|[a-z0-9.-]+\^$/.test(r.condition.urlFilter)) errs.push('bad filter on ' + r.id);
    }
    return errs;
  }
  return { parseList, dedupeParents, buildRules, allowRule, allowRules, toggleSite, validateRules, normHost, ALLOW_BASE, TYPES };
});
