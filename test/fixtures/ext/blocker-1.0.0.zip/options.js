const $ = (id) => document.getElementById(id), B = MFBlock, K = 'block.settings'; let st;
const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const save = () => chrome.storage.local.set({ [K]: st });
function draw() {
  $('on').checked = st.on;
  $('sites').innerHTML = st.off.length ? st.off.map((h) => '<div class="row"><div class="grow"><b>' + esc(h) + '</b></div><button class="btn sm" data-h="' + esc(h) + '" aria-label="Turn on for ' + esc(h) + '">Turn on</button></div>').join('') : '<div class="empty"><b>None</b>If a site breaks, turn the blocker off for it from the toolbar button.</div>';
}
$('on').onchange = async () => { st.on = $('on').checked; await save(); };
$('sites').onclick = async (e) => { const b = e.target.closest('[data-h]'); if (!b) return; st.off = B.toggleSite(st.off, b.dataset.h, false); await save(); draw(); };
fetch('rules/trackers.json').then((r) => r.json()).then((j) => { $('info').textContent = j.length + ' domains in the list'; });
chrome.storage.local.get(K).then((r) => { st = Object.assign({ on: true, off: [] }, r[K]); draw(); });
