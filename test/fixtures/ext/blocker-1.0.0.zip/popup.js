const $ = (id) => document.getElementById(id), B = MFBlock, K = 'block.settings'; let tab, host, st;
const save = () => chrome.storage.local.set({ [K]: { on: st.on, off: st.off } });
async function load() {
  st = await chrome.runtime.sendMessage({ type: 'block.state', tabId: tab.id });
  $('n').textContent = st.count == null ? '–' : st.count; $('all').checked = st.on; $('site').checked = !st.off.includes(B.normHost(host)); $('site').disabled = !st.on;
  $('what').textContent = !st.on ? 'blocker is off' : st.off.includes(B.normHost(host)) ? 'blocker is off on this site' : 'blocked on this page';
}
(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  host = tab && /^https?:/.test(tab.url || '') ? new URL(tab.url).hostname : ''; $('host').textContent = B.normHost(host);
  $('site').disabled = !host;
  $('all').onchange = async () => { st.on = $('all').checked; await save(); setTimeout(load, 200); };
  $('site').onchange = async () => { st.off = B.toggleSite(st.off, host, !$('site').checked); await save(); chrome.tabs.reload(tab.id); setTimeout(load, 400); };
  load();
})();
