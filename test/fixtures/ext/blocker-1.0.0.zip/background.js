importScripts('lib.js');
const B = MFBlock, DNR = chrome.declarativeNetRequest, K = 'block.settings';
const get = async () => Object.assign({ on: true, off: [] }, (await chrome.storage.local.get(K))[K]);

async function apply() {
  const s = await get();
  await DNR.updateEnabledRulesets(s.on ? { enableRulesetIds: ['trackers'] } : { disableRulesetIds: ['trackers'] });
  const old = (await DNR.getDynamicRules()).map((r) => r.id);
  await DNR.updateDynamicRules({ removeRuleIds: old, addRules: B.allowRules(s.off) });
  chrome.action.setBadgeBackgroundColor({ color: '#ffa800' });
  chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ color: '#0a0a0a' });
  await DNR.setExtensionActionOptions({ displayActionCountAsBadgeText: s.on });
}
chrome.runtime.onInstalled.addListener(apply);
chrome.runtime.onStartup.addListener(apply);
chrome.storage.onChanged.addListener((c) => { if (c[K]) apply(); });

chrome.runtime.onMessage.addListener((m, _s, reply) => {
  (async () => {
    if (m.type === 'block.state') {
      const s = await get(); let count = 0;
      try { const r = await DNR.getMatchedRules({ tabId: m.tabId }); count = r.rulesMatchedInfo.filter((x) => x.rule.rulesetId === 'trackers').length; } catch { count = null; }
      reply({ on: s.on, off: s.off, count });
    } else reply(null);
  })();
  return true;
});
