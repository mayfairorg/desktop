/* Clipper: pure logic. */
(function (root, factory) { const a = factory(); if (typeof module === 'object' && module.exports) module.exports = a; root.MFClip = a; })(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const KINDS = ['notes', 'tasks', 'drive'], SOURCES = ['page', 'selection', 'link'], MAX_TEXT = 200000, MAX_OUTBOX = 200;
  const cut = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  const oneLine = (s) => String(s || '').replace(/\s+/g, ' ').trim();

  function safeUrl(u) { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch { return ''; } }
  function fileName(title, ext) {
    const base = oneLine(String(title || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '')).replace(/\.+$/, '').slice(0, 80) || 'Clip';
    return base + '.' + (ext || 'md');
  }
  function markdown(c) {
    const out = ['# ' + (c.title || 'Clip'), ''];
    if (c.text) out.push(c.source === 'selection' ? c.text.split('\n').map((l) => '> ' + l).join('\n') : c.text, '');
    if (c.url) out.push('Source: ' + c.url);
    out.push('Saved: ' + new Date(c.t).toISOString().slice(0, 10));
    return out.join('\n') + '\n';
  }
  /* kind: notes | tasks | drive;  source: page | selection | link */
  function buildClip(input, now, id) {
    const kind = KINDS.includes(input.kind) ? input.kind : null; if (!kind) return { error: 'Choose Notes, Tasks or Drive' };
    const source = SOURCES.includes(input.source) ? input.source : 'page';
    const url = safeUrl(source === 'link' ? input.linkUrl : input.url);
    if (!url) return { error: 'Only web pages can be saved' };
    const text = cut(String(input.text || '').replace(/\r/g, '').trim(), MAX_TEXT);
    const title = cut(oneLine(input.title) || (source === 'link' ? url : 'Untitled page'), 200);
    const c = { id: id || 'c' + now.toString(36), kind, source, title, text: source === 'link' ? '' : text, url, from: safeUrl(input.url), t: now };
    if (kind === 'tasks') c.task = { title: cut(oneLine(source === 'selection' && text ? text : title), 140), notes: c.text.slice(0, 2000), link: url };
    if (kind === 'drive') { c.file = { name: fileName(title), type: 'text/markdown', body: markdown(c) }; }
    return { clip: c };
  }
  /* the message body the Mayfair web app receives (stub contract, v1) */
  function payloadFor(c) {
    const p = { id: c.id, kind: c.kind, title: c.title, url: c.url, source: c.source, t: c.t };
    if (c.kind === 'notes') p.note = { title: c.title, body: markdown(c) };
    if (c.kind === 'tasks') p.task = c.task;
    if (c.kind === 'drive') p.file = c.file;
    return p;
  }
  const enqueue = (outbox, clip) => { const o = (outbox || []).filter((x) => x.id !== clip.id).concat([clip]); return o.length > MAX_OUTBOX ? o.slice(o.length - MAX_OUTBOX) : o; };
  const ack = (outbox, id) => (outbox || []).filter((x) => x.id !== id);
  const label = { notes: 'Notes', tasks: 'Tasks', drive: 'Drive' };
  return { KINDS, buildClip, payloadFor, markdown, fileName, enqueue, ack, safeUrl, label };
});
