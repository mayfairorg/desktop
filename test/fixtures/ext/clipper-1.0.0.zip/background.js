importScripts('mf.js', 'lib.js');
const C = MFClip, S = MFX.store, X = MFX;
const MAYFAIR = X.MAYFAIR_ORIGINS.map((o) => o + '/*');

async function setBadge() { const n = (await S.get('clip.outbox', [])).length; chrome.action.setBadgeText({ text: n ? String(n) : '' }); chrome.action.setBadgeBackgroundColor({ color: '#ffa800' }); chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ color: '#0a0a0a' }); }

async function flush() {
  const tabs = await chrome.tabs.query({ url: MAYFAIR }); const out = await S.get('clip.outbox', []);
  if (!tabs.length || !out.length) return { sent: 0, waiting: out.length, open: !!tabs.length };
  for (const c of out) for (const t of tabs.slice(0, 1)) chrome.tabs.sendMessage(t.id, { type: 'bridge.out', envelope: X.envelope(X.MSG.CLIP, C.payloadFor(c), c.id) }).catch(() => {});
  return { sent: out.length, waiting: out.length, open: true };   /* removed from the outbox only when the page acknowledges */
}

async function save(input) {
  const r = C.buildClip(input, Date.now()); if (r.error) return r;
  await S.set('clip.outbox', C.enqueue(await S.get('clip.outbox', []), r.clip));
  const f = await flush(); await setBadge();
  return { ok: true, clip: r.clip, delivered: f.open, waiting: (await S.get('clip.outbox', [])).length };
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  (async () => {
    if (m.type === 'clip.save') reply(await save(m.input));
    else if (m.type === 'clip.state') reply({ outbox: await S.get('clip.outbox', []), open: (await chrome.tabs.query({ url: MAYFAIR })).length > 0 });
    else if (m.type === 'clip.flush') { reply(await flush()); }
    else if (m.type === 'clip.discard') { await S.set('clip.outbox', C.ack(await S.get('clip.outbox', []), m.id)); await setBadge(); reply({ ok: true }); }
    else if (m.type === 'bridge.hello') { if (sender.tab) { await flush(); } reply(null); }
    else if (m.type === 'bridge.in' && sender.tab && X.isMayfairOrigin(new URL(sender.tab.url).origin) && X.validEnvelope(m.envelope) && m.envelope.type === X.MSG.CLIP_ACK) {
      const id = m.envelope.payload && m.envelope.payload.id;
      if (typeof id === 'string') await S.set('clip.outbox', C.ack(await S.get('clip.outbox', []), id));
      await setBadge(); reply(null);
    } else reply(null);
  })().catch((e) => reply({ error: String(e && e.message || e) }));
  return true;
});

const MENUS = [['notes', 'Save to Notes'], ['tasks', 'Save to Tasks'], ['drive', 'Save to Drive']];
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'mf', title: 'Save to Mayfair', contexts: ['page', 'selection', 'link'] });
    for (const [k, t] of MENUS) chrome.contextMenus.create({ id: 'mf.' + k, parentId: 'mf', title: t, contexts: ['page', 'selection', 'link'] });
  });
  setBadge();
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!String(info.menuItemId).startsWith('mf.') || !tab) return;
  const kind = info.menuItemId.slice(3);
  const source = info.linkUrl ? 'link' : info.selectionText ? 'selection' : 'page';
  let text = info.selectionText || '';
  if (source === 'page') { try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body && document.body.innerText || '').slice(0, 20000) }); text = r.result || ''; } catch { /* restricted page */ } }
  const r = await save({ kind, source, url: tab.url, title: tab.title, text, linkUrl: info.linkUrl });
  chrome.action.setBadgeText({ tabId: tab.id, text: r.ok ? '✓' : '!' });
  setTimeout(setBadge, 1800);
});
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== 'save-notes') return; const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!tab) return;
  let text = ''; try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => String(getSelection()) }); text = r.result || ''; } catch { /* ignore */ }
  save({ kind: 'notes', source: text ? 'selection' : 'page', url: tab.url, title: tab.title, text });
});
chrome.tabs.onUpdated.addListener((id, ch, tab) => { if (ch.status === 'complete' && tab.url && X.isMayfairOrigin(new URL(tab.url).origin)) flush(); });
