const $ = (id) => document.getElementById(id), send = (m) => chrome.runtime.sendMessage(m);
let tab, sel = '';
async function init() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => String(getSelection()) }); sel = r.result || ''; } catch { sel = ''; }
  $('what').textContent = !tab || !MFX.isHttp(tab.url) ? 'Open a web page first' : sel ? 'Your selection (' + sel.length + ' characters)' : 'This page';
  if (!tab || !MFX.isHttp(tab.url)) document.querySelectorAll('[data-k]').forEach((b) => b.disabled = true);
  waiting();
}
document.querySelector('.bar').onclick = async (e) => {
  const b = e.target.closest('[data-k]'); if (!b) return; b.disabled = true;
  let text = sel; if (!text) { try { const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => (document.body.innerText || '').slice(0, 20000) }); text = r.result || ''; } catch { /* ignore */ } }
  const r = await send({ type: 'clip.save', input: { kind: b.dataset.k, source: sel ? 'selection' : 'page', url: tab.url, title: tab.title, text } });
  b.disabled = false;
  $('msg').className = 'note ' + (r.ok ? 'ok' : 'err');
  $('msg').textContent = r.error ? r.error : r.delivered ? 'Sent to ' + MFClip.label[b.dataset.k] : 'Saved here. It will go to ' + MFClip.label[b.dataset.k] + ' when Mayfair is open.';
  waiting();
};
async function waiting() {
  const s = await send({ type: 'clip.state' }), el = $('wait');
  if (!s.outbox.length) { el.innerHTML = ''; return; }
  el.innerHTML = '<h2 style="margin-top:16px">Waiting (' + s.outbox.length + ')</h2>' + s.outbox.slice(-4).reverse().map((c) => '<div class="row"><div class="grow"><b>' + MFX.esc(c.title) + '</b><small>' + MFClip.label[c.kind] + ' · ' + MFX.ago(c.t) + '</small></div><button class="btn sm" data-d="' + MFX.esc(c.id) + '" aria-label="Discard">Discard</button></div>').join('') +
    (s.open ? '<div class="bar" style="margin-top:8px"><button class="btn sm" id="retry">Send now</button></div>' : '<div class="bar" style="margin-top:8px"><button class="btn sm" id="openm">Open Mayfair</button></div>');
  el.onclick = async (e) => {
    const d = e.target.closest('[data-d]'); if (d) { await send({ type: 'clip.discard', id: d.dataset.d }); waiting(); }
    if (e.target.id === 'retry') { await send({ type: 'clip.flush' }); setTimeout(waiting, 600); }
    if (e.target.id === 'openm') chrome.tabs.create({ url: 'https://cloud.mayfairmail.com/' });
  };
}
init();
