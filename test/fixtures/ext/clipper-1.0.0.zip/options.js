const $ = (id) => document.getElementById(id);
async function show() { const n = (await MFX.store.get('clip.outbox', [])).length; $('count').textContent = n ? n + ' waiting to be sent' : 'Nothing waiting'; }
$('clear').onclick = async () => { await MFX.store.set('clip.outbox', []); chrome.action.setBadgeText({ text: '' }); show(); };
show();
